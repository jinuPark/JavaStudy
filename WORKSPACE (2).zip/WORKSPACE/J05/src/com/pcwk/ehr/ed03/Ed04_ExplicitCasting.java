package com.pcwk.ehr.ed03;

public class Ed04_ExplicitCasting {

	public static void main(String[] args) {
		 // 명시적 형변환
		int iNum = 12;
		byte bNum = (byte)iNum;

		System.out.println("iNum=" + iNum);
		System.out.println("bNum=" + bNum);
		System.out.println("----------------------");
		iNum = 129;
		bNum = (byte)iNum;

		System.out.println("iNum=" + iNum);
		System.out.println("bNum=" + bNum); // 쓰레기 값 발생
		
		// 더 정밀한 수에서 덜 정밀한 변수로 대입
		double dNum = 3.14; // 실수에 default는 double 그러므로
							// 서픽스 d 생략 가능
		iNum = (int)dNum;
		System.out.println("dNum=" + dNum);
		System.out.println("iNum=" + iNum);

	}

}
