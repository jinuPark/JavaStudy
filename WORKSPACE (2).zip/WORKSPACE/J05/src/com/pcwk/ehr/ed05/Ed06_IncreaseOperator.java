package com.pcwk.ehr.ed05;

public class Ed06_IncreaseOperator {

	public static void main(String[] args) {
		int i = 12;
		i++; // i = i + 1;
		
		System.out.println("i++="+i);
		
		i = 12;
		++i;
		
		System.out.println("i++="+i);
		
	}

}

