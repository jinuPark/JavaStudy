package com.pcwk.ehr.ed07;

public class Ed09_ArthOperator {

	public static void main(String[] args) {
		// int / int
		
		// Exception in thread "main" java.lang.ArithmeticException: / by zero
		// System.out.println(12/0);
		
		// int / double
		System.out.println(12/0.0);// Infinity
		System.out.println(-12/0.0);// Infinity
		
		
		
	}

}
//Infinity
//-Infinity
