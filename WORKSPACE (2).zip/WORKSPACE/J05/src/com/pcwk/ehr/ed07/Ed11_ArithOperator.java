package com.pcwk.ehr.ed07;

public class Ed11_ArithOperator {
	
	public static void main(String[] args) {
		int x = 1_000_000;	// 1백만
		int y = 2_000_000;	// 2백만

		long result = x * y; // int * int -> int(오버플로 발생)
		System.out.println("result="+result);//쓰레기 값
	}

}
