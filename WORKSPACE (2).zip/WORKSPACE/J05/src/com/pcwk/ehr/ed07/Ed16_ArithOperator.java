package com.pcwk.ehr.ed07;

public class Ed16_ArithOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float pi = 3.141592f;

		float shortPI = (int)(pi * 1000 + 0.5)/1000f;
		System.out.println("shortPI="+shortPI);

	}

}
