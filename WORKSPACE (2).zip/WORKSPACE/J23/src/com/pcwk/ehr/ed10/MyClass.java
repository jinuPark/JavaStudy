package com.pcwk.ehr.ed10;

public class MyClass {

	@MyAnnotation(value = "애너테이션 테스트99")
	public void myMethod() {
		
	}
}
