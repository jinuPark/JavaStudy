package com.pcwk.ehr.ed04;

import com.pcwk.ehr.cmn.PLogger;

public class Ed04_GenericsMain implements PLogger {

	public static void main(String[] args) {
		
		FruitBox<Fruit> fruitBox=new FruitBox<Fruit>();
		
		fruitBox.add(new Fruit());
		fruitBox.add(new Apple());
		fruitBox.add(new Grape());
		
		
		System.out.println("fruitBox:"+fruitBox);
		System.out.println("=================================================");
		
		FruitBox<Grape> grapeBox=new FruitBox<Grape>();
		grapeBox.add(new Grape());
		//grapeBox.add(new Fruit());
		
		System.out.println("grapeBox:"+grapeBox);
		System.out.println("=================================================");
		
		//FruitBox<Toy>  toyBox=new FruitBox<Toy>();//Bound mismatch
		
		
		
		
	}

}