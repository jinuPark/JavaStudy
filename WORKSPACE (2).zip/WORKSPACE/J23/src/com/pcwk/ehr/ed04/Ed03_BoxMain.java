/*
 * package com.pcwk.ehr.ed04;
 * 
 * public class Ed03_BoxMain {
 * 
 * public static void main(String[] args) { Box<Fruit> fruitBox = new
 * Box<Fruit>();
 * 
 * fruitBox.add(new Fruit()); fruitBox.add(new Apple());
 * System.out.println("fruitBox:"+fruitBox);
 * 
 * System.out.println("======================"); Box<Apple> appleBox = new
 * Box<Apple>();
 * 
 * appleBox.add(new Apple()); appleBox.add(new Apple()); //appleBox.add(new
 * Toy()); 에러: Box<Apple>에는 Apple만 담을수 있음!
 * System.out.println("appleBox:"+appleBox);
 * 
 * System.out.println("======================");
 * 
 * //Box<Grape> grapeBox = new Box<Grape>();//Type mismatch Box<Toy> toyBox =
 * new Box<Toy>(); toyBox.add(new Toy()); //toyBox.add(new Apply());
 * System.out.println("toyBox:"+toyBox);
 * 
 * }
 * 
 * } //fruitBox:Box [list=[Fruit, Apple]] //======================
 * //appleBox:Box [list=[Apple, Apple]] //====================== //toyBox:Box
 * [list=[Toy]]
 * 
 */