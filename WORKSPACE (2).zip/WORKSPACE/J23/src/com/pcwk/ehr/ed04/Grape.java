package com.pcwk.ehr.ed04;

public class Grape extends Fruit {

	@Override
	public String toString() {
		return "Grape";
	}

}
