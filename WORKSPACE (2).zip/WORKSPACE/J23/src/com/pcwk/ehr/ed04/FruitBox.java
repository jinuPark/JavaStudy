package com.pcwk.ehr.ed04;

public class FruitBox<T extends Fruit & Eatable> extends Box<T> {

}