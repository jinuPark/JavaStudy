package com.pcwk.ehr.ed04;

public class Apple extends Fruit {

	@Override
	public String toString() {
		return "Apple";
	}
	
	

}
