package com.pcwk.ehr.ed04;

public class Fruit implements Eatable {

	@Override
	public String toString() {
		return "Fruit";
	}
	
}
