package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;

public class Ed01_BoxMain implements PLogger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LOG.debug("==================");
		
		Box<String> strBox = new Box<String>();
		
		//int는 담을 수 없음
		//strBox.setContent(1);
		strBox.setContent("오늘은 즐거운 금요일");

		// 캐스팅 생략
		String content = strBox.getContent();
		LOG.debug("content:"+content);
		
		
		Box<Integer> intBox = new Box<Integer>();
		intBox.setContent(1);
		
		int intContent = intBox.getContent();
		LOG.debug("intContent:"+intContent);
		
	}

}

//[2023-10-13 10:08:26] DEBUG Ed01_BoxMain.main(Ed01_BoxMain.java:9) - ==================
//[2023-10-13 10:08:26] DEBUG Ed01_BoxMain.main(Ed01_BoxMain.java:19) - content:오늘은 즐거운 금요일
//[2023-10-13 10:08:26] DEBUG Ed01_BoxMain.main(Ed01_BoxMain.java:26) - intContent:1