package com.pcwk.ehr.ed03;

public class Fruit {

	@Override
	public String toString() {
		return "Fruit";
	}

	
	
}
