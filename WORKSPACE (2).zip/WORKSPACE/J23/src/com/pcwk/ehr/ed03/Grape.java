package com.pcwk.ehr.ed03;

public class Grape extends Fruit {

	@Override
	public String toString() {
		return "Grape";
	}

}
