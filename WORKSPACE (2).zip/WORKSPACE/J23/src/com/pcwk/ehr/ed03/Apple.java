package com.pcwk.ehr.ed03;

public class Apple extends Fruit {

	@Override
	public String toString() {
		return "Apple";
	}
	
	

}
