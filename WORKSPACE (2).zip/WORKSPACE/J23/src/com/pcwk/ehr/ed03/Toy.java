package com.pcwk.ehr.ed03;

public class Toy {

	@Override
	public String toString() {
		return "Toy";
	}

}
