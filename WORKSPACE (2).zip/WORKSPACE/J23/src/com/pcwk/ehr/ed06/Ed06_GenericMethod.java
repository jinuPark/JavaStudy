package com.pcwk.ehr.ed06;

public class Ed06_GenericMethod {

	// 배열의 출력 일반화 : Integer, String, ... 배열을 받아 내부에 모든 요소 출력
	public static <T> T printArrayAll(T[] arr) {
		for(T n:arr) {
			System.out.print(n+",");
		}
		System.out.println();
		return arr[0];
	}
	
	public static void main(String[] args) {
		Integer[] intArray = {12,14,17,46};
		printArrayAll(intArray);
		
		Double[] doubleArray = {1.0, 2.2, 3.3};
		printArrayAll(doubleArray);
		
		String[] stringArray = {"one", "two", "three"};
		String strFirst = printArrayAll(stringArray);
		System.out.println("strFirst:"+strFirst);
		
	}

}

//12,14,17,46,
//1.0,2.2,3.3,
//one,two,three,
//strFirst:one
