package com.pcwk.ehr.ed08;

public enum TrafficSignal {
	//RED		-> stop
	//GREEN		-> go
	//YELLOW	-> Slow
	RED("Stop"),GREEN("GO"),YELLO("Slow down");
	
	private String action;
	
	TrafficSignal(String action) {
		this.action = action;
	}
	
	public String getAction() {
		return action;
	}
	
}
