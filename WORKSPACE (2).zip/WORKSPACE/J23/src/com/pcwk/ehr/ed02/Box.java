package com.pcwk.ehr.ed02;

public class Box {
	
	private Object content;
	
	public Box() {}

	/**
	 * @param content
	 */
	public Box(Object content) {
		super();
		this.content = content;
	}

	/**
	 * @return the content
	 */
	public Object getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(Object content) {
		this.content = content;
	}
	
	
	
}