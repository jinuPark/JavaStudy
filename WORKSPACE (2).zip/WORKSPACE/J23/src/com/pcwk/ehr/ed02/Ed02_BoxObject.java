package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;

public class Ed02_BoxObject implements PLogger {

	public static void main(String[] args) {
		Box strBox=new Box();
		
		strBox.setContent("즐거운 금요일");
		//strBox.setContent(22);
		
		String content = (String) strBox.getContent();//캐스팅 발생
		LOG.debug("content:"+content);//content:즐거운 금요일
	}

}