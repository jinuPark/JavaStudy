package com.pcwk.ehr.ed09;

public class Child extends Parent {

	
	@Override //오버라이드 문법 체크
	void parentMethod() {
		
	}
	//The method parentMethod99() of type Child must override or
  // implement a supertype method
}