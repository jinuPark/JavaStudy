package com.pcwk.ehr.ed05;

public class Juice {

	String name;

	/**
	 * @param name
	 */
	public Juice(String name) {
		super();
		this.name = name+" Juice";
	}

	@Override
	public String toString() {
		return "Juice [name=" + name + "]";
	}
	
}
