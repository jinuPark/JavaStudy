package com.pcwk.ehr.ed05;

public interface Eatable {

}
