package com.pcwk.ehr.ed05;

public class FruitBox<T extends Fruit > extends Box<T> {

}