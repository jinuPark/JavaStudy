package com.pcwk.ehr.ed05;

public class Apple extends Fruit {

	@Override
	public String toString() {
		return "Apple";
	}

}
