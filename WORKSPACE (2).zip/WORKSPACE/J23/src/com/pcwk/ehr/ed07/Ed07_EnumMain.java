package com.pcwk.ehr.ed07;

import com.pcwk.ehr.cmn.PLogger;

public class Ed07_EnumMain implements PLogger {

	public static void main(String[] args) {
		Day today = Day.FRIDAY;
		
		//Today is FRIDAY
		System.out.println("Today is "+today);
		
		Day[] dArray = Day.values();
		
		for(Day d : dArray) {
			// name() : 이름, ordinal() : 위치 값
			System.out.printf("%s = %d\n",d.name(),d.ordinal());
		}
		
	}

}

//Today is FRIDAY
//SUNDAY = 0
//MONDAY = 1
//TUESDAY = 2
//WEDNESDAY = 3
//THURSDAY = 4
//FRIDAY = 5
//SATURDAY = 6
