public class Ed09_Main {

	//@Deprecated : 컴파일 deprecation warning 메시지 출력되지 않게 하기

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Ed09_Deprecated dep = new Ed09_Deprecated();
		
		dep.oldAge = 23;

		System.out.println(dep.getOldAge());
		
	}

}
