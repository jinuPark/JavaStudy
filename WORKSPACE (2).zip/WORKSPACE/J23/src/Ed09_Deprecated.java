public class Ed09_Deprecated {
	int age;
	
	@Deprecated
	public int oldAge;


	/**
	 * @return the oldAge
	 */
	@Deprecated
	public int getOldAge() {
		return oldAge;
	}

}
