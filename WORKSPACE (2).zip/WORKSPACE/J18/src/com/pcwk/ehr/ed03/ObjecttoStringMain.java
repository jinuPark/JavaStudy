package com.pcwk.ehr.ed03;

public class ObjecttoStringMain {

	public static void main(String[] args) {
		Card card01 = new Card();
		Card card02 = new Card();
		
		//card01:com.pcwk.ehr.ed03.Card@15db9742
		//card01객체를 출력 하면, card01.toString()가 호출 된다.
		//return getClass().getName() + "@" + Integer.toHexString(hashCode());
		System.out.println("card01:"+card01);
		System.out.println("card01.toString():"+card01.toString());
		
		//객체마다 인스턴스 주소가 다르다
		System.out.println("card02:"+card02.toString());
	}

}


//card01:com.pcwk.ehr.ed03.Card@15db9742
//card01.toString():com.pcwk.ehr.ed03.Card@15db9742
//card02:com.pcwk.ehr.ed03.Card@6d06d69c