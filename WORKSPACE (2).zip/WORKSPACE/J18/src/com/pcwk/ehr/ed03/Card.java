package com.pcwk.ehr.ed03;

public class Card {
	String kind;//무늬
	int number;//숫자
	
	Card() {
		//인자 2개 생성자 호출
		this("spade",1);
		
	}
	

	public Card(String kind, int number) {
		super();
		this.kind = kind;
		this.number = number;
	}
}
