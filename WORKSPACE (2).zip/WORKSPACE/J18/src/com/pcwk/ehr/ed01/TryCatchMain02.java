package com.pcwk.ehr.ed01;

public class TryCatchMain02 {

	public static void main(String[] args) {
		System.out.println("A");
		System.out.println("B");
		try {
			System.out.println("C");
			System.out.println(21/0);
			System.out.println("D");
		} catch (ArithmeticException e) {
			System.out.println("E");
			e.printStackTrace();
			System.out.println("ArithmeticException:"+e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		System.out.println("┌==========┐");
		System.out.println("│프로그램 종료 │");
		System.out.println("└==========┘");
		
	}

}


//A
//B
//C
//E
//ArithmeticException:/ by zero
//┌==========┐
//│프로그램 종료 │
//└==========┘
//java.lang.ArithmeticException: / by zero
//	at com.pcwk.ehr.ed01.TryCatchMain02.main(TryCatchMain02.java:10)

