package com.pcwk.ehr.ed04;

public class ObjectOverridingStringMain {

	public static void main(String[] args) {
		Card card01 = new Card();

		System.out.println(card01);
		System.out.println(card01.toString());

	}

}

//Card[kind=spade,number=1]com.pcwk.ehr.ed04.Card@15db9742
//Card[kind=spade,number=1]com.pcwk.ehr.ed04.Card@15db9742
