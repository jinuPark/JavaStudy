package com.pcwk.ehr.ed04;

public class Card {
	String kind;//무늬
	int number;//숫자
	
	Card() {
		//인자 2개 생성자 호출
		this("spade",1);
		
	}
	

	public Card(String kind, int number) {
		super();
		this.kind = kind;
		this.number = number;
	}


	@Override
	public String toString() {
		return "Card [kind=" + kind + ", number=" + number + ", toString()=" + super.toString() + "]";
	}
	
//	@Override
//	public String toString() {
//		return "Card[kind="+kind+",number="+number+"]"+super.toString();
//	}
	
	
	
}
