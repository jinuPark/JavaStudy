package com.pcwk.ehr.ed09;

public class EqualsMain {

	public static void main(String[] args) {
		Person person01 = new Person(1234567890);
		Person person02 = new Person(1234567890);
		
		System.out.println("person01.equals(person02):"+person01.equals(person02));
	}

}
