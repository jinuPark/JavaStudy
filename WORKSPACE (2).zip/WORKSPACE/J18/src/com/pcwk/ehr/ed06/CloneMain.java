package com.pcwk.ehr.ed06;

public class CloneMain {

	public static void main(String[] args) {
		Pointer pointer = new Pointer(14,12);
		Pointer pointerClone = (Pointer) pointer.clone();

		System.out.println("원본:"+pointer.toString());
		System.out.println("Clone:"+pointerClone.toString());
		
		//clone 데이터 변경
		pointerClone.x = 17;
		System.out.println("======================");
		System.out.println("원본:"+pointer.toString());
		System.out.println("Clone:"+pointerClone.toString());
	}

}

//원본:Pointer [x=14, y=12]
//Clone:Pointer [x=14, y=12]
//======================
//원본:Pointer [x=14, y=12]
//Clone:Pointer [x=17, y=12]