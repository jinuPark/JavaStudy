package com.pcwk.ehr.ed10;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.pcwk.ehr.ed12.ClassMain;

public class EqualsMain {

	static final Logger LOG = LogManager.getLogger(ClassMain.class);
	
	public static void main(String[] args) {
		Person person01 = new Person(1234567890);
		Person person02 = new Person(1234567890);
		
//
//		동일한 데이터를 가지고 있어도 동일하지 않음		
//	    public boolean equals(Object obj) {
//	        return (this == obj);
//	    }
		//person01.equals(person02):false
		System.out.println("person01.equals(person02):"+person01.equals(person02));
		System.out.println(person01.toString());
		System.out.println(person02.toString());
		

		LOG.debug("person01:"+person01.toString());
		LOG.debug("person02:"+person02.toString());
	}

}

//person01.equals(person02):true
//Person [id=1234567890]
//Person [id=1234567890]
