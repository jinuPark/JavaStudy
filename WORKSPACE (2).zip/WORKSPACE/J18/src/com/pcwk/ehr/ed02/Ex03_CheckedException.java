package com.pcwk.ehr.ed02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Ex03_CheckedException {

	public static void main(String[] args) {
		// C:\JSPM_0907\01_JAVA\WORKSPACE\J18\src\com\pcwk\ehr\ed02\Ex03_CheckedException.java
		try {
			FileInputStream fis = new FileInputStream("C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J18\\src\\com\\pcwk\\ehr\\ed02\\Ex03_CheckedException.java");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}