package com.pcwk.ehr.ed02;

public class ACORNException extends Exception {
	
	public ACORNException(String message) {
		super(message);
	}

}

//ACORNException : 나이를 확인 하세요.나이는 18세 이상이어야 합니다.
//┌==========┐
//│프로그램 종료 │
//└==========┘
