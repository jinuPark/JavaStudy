package com.pcwk.ehr.ed02;

public class Ex10_Throws {
	

	public static void main(String[] args) {
		
		try {
			checkAge(15); //메소드를 호출한 쪽. try처리해주기.
			//checkAge(19);
		} catch(IllegalArgumentException e) {
			System.err.println("IllegalArgumentException : 나이를 확인 하세요."
			+e.getMessage());
		} catch(ArrayIndexOutOfBoundsException e) { // 나열한 만큼 catch
			System.err.println("ArrayIndexOutOfBoundsException : 나이를 확인 하세요."
			+e.getMessage());
		}

		
		System.out.println("┌==========┐");
		System.out.println("│프로그램 종료 │");
		System.out.println("└==========┘");
	}

	//static void checkAge(int age) throws IllegalArgumentException{
	static void checkAge(int age) throws IllegalArgumentException, ArrayIndexOutOfBoundsException{
		if(age < 18) {
			throw new IllegalArgumentException("나이는 18세 이상이어야 합니다.");
		} else {
			System.out.println("사이트에 access 가능 합니다.");
		}
	}
}



//IllegalArgumentException : 나이를 확인 하세요.나이는 18세 이상이어야 합니다.
//┌==========┐
//│프로그램 종료 │
//└==========┘

