package com.pcwk.ehr.ed02;

public class Ex09_Throw {
	
	public static void main(String[] args) {
		int age = -1;
		
		try {		
		if(age < 0) {
			throw new IllegalArgumentException("나이는 음수 일 수 없습니다.");
			}
		} catch(IllegalArgumentException e) {
			System.err.println("예외발생:"+e.getMessage());
		}
		
		System.out.println("나이는 "+age+"세 입니다.");
	}
	

}

//예외발생:나이는 음수 일 수 없습니다.
//나이는 -1세 입니다.

