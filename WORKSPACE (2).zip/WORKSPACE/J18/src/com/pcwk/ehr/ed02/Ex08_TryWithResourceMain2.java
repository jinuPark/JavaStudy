package com.pcwk.ehr.ed02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ex08_TryWithResourceMain2 {
	//try-with-resource 사용하지 않은 경우 : finally구문이 매우 장대함
	
	public static void main(String[] args) {
		String orgFilename = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J18\\src\\com\\pcwk\\ehr\\ed02\\Ex07_TryWithResourceMain.java";
		String saveFilename = "CopyEx07_TryWithResourceMain.java";
		// File읽기, File쓰기
		// FileInputStream, FileOutputStream : AutoCloseable인터페이스를 implements 받고 있음
		// JVM이 알아서 close()처리를 하므로 finally 구문 불필요!
		// Ex07_TryWithResourceMain -> copyEx07_TryWithResourceMain
		try (FileInputStream fis = new FileInputStream(orgFilename);
			FileOutputStream fos = new FileOutputStream(saveFilename);
				)	{
	
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) { // 예외처리의 최 상위 조상
			e.printStackTrace();
		}
		//finally 구문 불필요!
		

	}

}
