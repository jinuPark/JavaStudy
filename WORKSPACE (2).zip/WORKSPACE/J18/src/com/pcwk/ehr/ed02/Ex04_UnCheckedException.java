package com.pcwk.ehr.ed02;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Ex04_UnCheckedException {

	public static void main(String[] args) {
		
		int[] numbers = {12,14,17};
		int index = 4;
		
		try {
		int result = numbers[index];
		System.out.println(result);
		} catch(ArrayIndexOutOfBoundsException e) {
			System.err.println("배열 범위를 벗어난 접근 예외:"+e.getMessage());
		}
		
		System.out.println("┌==========┐");
		System.out.println("│프로그램 종료 │");
		System.out.println("└==========┘");
		
		
	}

}
