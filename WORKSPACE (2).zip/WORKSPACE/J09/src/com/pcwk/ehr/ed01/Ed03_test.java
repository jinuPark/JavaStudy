package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed03_test {

	public static void main(String[] args) {
		int []studentsScore;//배열 선언
		
		studentsScore = new int[5];// 배열 생성
		System.out.println(studentsScore[0]); // int에 default인 0으로 초기화
		
		int i = 1;
		
		// 배열 요소에 값 할당
		studentsScore[0] = 77;
		studentsScore[1] = 88;
		studentsScore[i+1] = 89;	// studentScore[2]
		studentsScore[i+2] = 92;	// studentScore[3]
		studentsScore[4] = 95;	// studentScore[4]
		
		// 배열에 할당된 요소값 출력
		int tmpScore = studentsScore[0];
		System.out.printf("tmpScore=%d\n", tmpScore);
		
		// 배열요소 인덱스[1] + 인덱스[2]
		tmpScore = studentsScore[1] + studentsScore[2];
		System.out.printf("studentsScore[1] + studentsScore[2]=%d\n", tmpScore);
		
		//배열이름.length : 배열의 길이
		System.out.printf("배열이름.length=%d\n",studentsScore.length);
		
		//배열의 전체데이터 접근
		//배열의 길이는 JVM이관리
		for(i=0; i<studentsScore.length; i++) {
			System.out.printf("i=%d, studentsScore[%d]=%d\n", i,i,studentsScore[i]);
		}
	}// -- main
	
}// -- class


//0
//tmpScore=77
//studentsScore[1] + studentsScore[2]=177
//배열이름.length=5
//i=0, studentsScore[0]=77
//i=1, studentsScore[1]=88
//i=2, studentsScore[2]=89
//i=3, studentsScore[3]=92
//i=4, studentsScore[4]=95

