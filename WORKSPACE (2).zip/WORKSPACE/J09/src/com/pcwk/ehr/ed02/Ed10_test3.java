package com.pcwk.ehr.ed02;

import java.util.Arrays;


public class Ed10_test3 {

	public static void main(String[] args) {
		// 배열의 요소의 순서를 반복해서 바꾼다.

		int []num = new int[10];		

		for(int i = 0; i < num.length; i++) {
			num[i] = i;
		}
		
		// [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

		System.out.println("suffle 전");
		System.out.println(""+Arrays.toString(num));
		System.out.println("================");
		
		for(int i = 0; i < 50; i++) {
			int n = (int)(Math.random()*10);	//	0.0 <= x < 1.0
			//System.out.println("n="+n);
			int temp = num[0];	//	배열요소 0
			num[0]	 = num[n];	//	배열요소 0
			num[n]	 = temp;
				
		}

		System.out.println("suffle 후");
		for(int i = 0; i < num.length; i++) {
			System.out.printf("num[%d]=%d\n", i, num[i]);		
		}
	}
}
//suffle 전
//[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
//================
//suffle 후
//num[0]=3
//num[1]=7
//num[2]=5
//num[3]=4
//num[4]=2
//num[5]=0
//num[6]=1
//num[7]=8
//num[8]=9
//num[9]=6


