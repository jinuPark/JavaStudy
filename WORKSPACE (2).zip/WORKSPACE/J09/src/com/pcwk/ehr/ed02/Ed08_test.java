package com.pcwk.ehr.ed02;

import java.util.Arrays;

public class Ed08_test {

	public static void main(String[] args) {
//		배열의 모든 요소를 더해서 총합과 평균을 구하세요.
//		int []studentScore = {79, 88, 55, 100, 77}
		int sum = 0; 		// 합계
		double avg = 0.0;	// 평균
		int []score = { 79, 88, 55, 100, 77 };
		
		for(int i = 0; i < score.length; i++) {
			sum += score[i];
		}
		
		System.out.printf("합계 : %d\n", sum);
		
		avg = sum / (score.length * 1.0);
		System.out.printf("평균 :" + avg);
		
	}
}
