package com.pcwk.ehr.ed02;

public class Ed05_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int iArray01[] = new int[5];
		
		//전체 iArray01[] 출력
		//iArray01.length를 쓰는 이유는 초기화할 때
		//코드 수정하지 않고 그대로 사용하기위함
		for(int i = 0; i < iArray01.length; i++) {
			System.out.printf("iArray01[%d] = %d\n=", i, iArray01[i]);
		}
		
		// 배열 생성과 동시에 초기화
		int []iArray02 = new int[] {77,88,79,95,99};
		
		// 배열 생성과 동시에 초기화 'new int[]' 생략
		int []iArray03 = {77,88,79,95,99};
		
		System.out.printf("iArray03.length=%d\n", iArray03.length);
		
		//iArray03 전체 데이터 출력
		
		//i <= iArray03.length 
		//해주면 java.lang.ArrayIndexOutOfBoundsException 에러발생
		for (int i = 0; i < iArray03.length; i++) {
			System.out.printf("iArray03[%d] = %d\n=", i, iArray03[i]);
		}

		System.out.println("============================================");
		// 합계, 평균
		int sum = 0; //합계
		double avg = 0.0; //평균

		for(int i = 0; i<iArray03.length; i++) {
			//sum += Array03[i];
			sum = sum + iArray03[i];
		}
		
		System.out.println("sum="+sum);
		//평균
		avg = sum / (iArray03.length * 1.0);
		System.out.println("avg="+avg);
	}

}


//iArray01[0] = 0
//=iArray01[1] = 0
//=iArray01[2] = 0
//=iArray01[3] = 0
//=iArray01[4] = 0
//=iArray03.length=5
//iArray03[0] = 77
//=iArray03[1] = 88
//=iArray03[2] = 79
//=iArray03[3] = 95
//=iArray03[4] = 99
//=============================================
//sum=438
//avg=87.6
