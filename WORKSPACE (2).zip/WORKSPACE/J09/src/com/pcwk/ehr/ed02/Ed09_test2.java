package com.pcwk.ehr.ed02;

import java.util.Arrays;

public class Ed09_test2 {

	public static void main(String[] args) {
//		배열의 요소 중에서 제일 큰 값과 제일 작은 값을 찾는다.
//		int []score = { 79, 88, 55, 100, 77, 66, 87};

		int []score = { 79, 88, 55, 100, 77, 66, 87};
		int max = 0;		// 최대값
		int min = 0;		// 최소값
		
		max = score[0];
		System.out.println("max="+max);		
		min = score[0];
		System.out.println("min="+min);
		

		System.out.println("==================");
		
		
		for(int i = 0; i < score.length; i++) {
			if( max < score[i] ) {
				max = score[i];

				
			}
			
			if( min > score[i] ){
				min = score[i];

			}
			
		}
		System.out.println("최대값 :" + max);
		System.out.println("최소값 :" + min);
		
		
		
	}
}

//max=79
//min=79
//==================
//최대값 :100
//최소값 :55


