package com.pcwk.ehr.ed02;

public class Ed04_array {

	public static void main(String[] args) {
		// 1+(1+2)+(1+2+3)+(1+2+3+4)+...+(1+2+3+...+10)의 결과를 계산하시오.
		// totalSum = 220
		int totalSum = 0;
		for (int i = 1; i <= 10; i++) {
			int subTotal = 0;
			for (int j = 1; j <= i; j++) {
				
				subTotal += j;
				System.out.printf("%d", j);
			}
			System.out.printf("\t\t\t %d", subTotal);
			totalSum += subTotal;
			
			System.out.println();
		}
		System.out.printf("totalSum = "+totalSum);
	}

}


//1			 1
//12			 3
//123			 6
//1234			 10
//12345			 15
//123456			 21
//1234567			 28
//12345678			 36
//123456789			 45
//12345678910			 55
//totalSum = 220
