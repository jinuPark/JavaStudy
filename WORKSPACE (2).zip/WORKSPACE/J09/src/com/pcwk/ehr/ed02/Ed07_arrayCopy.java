package com.pcwk.ehr.ed02;

import java.util.Arrays;

public class Ed07_arrayCopy {

	public static void main(String[] args) {
		int []srcArray = {1, 2, 3, 4, 5};
		int []targetAarray = {0, 0, 0, 0, 0, 0};
		
		//srciArray to copy targetarray
		for(int i = 0; i < srcArray.length; i++) {
			System.out.printf("srciArray[%d]=%d\n", i, srcArray[i]);
		}
		//Arrays.toString() : 배열에 들어 있는 모든 요소 출력
		System.out.println("Copy전 데이터");
		System.out.println(Arrays.toString(srcArray));
		System.out.println(Arrays.toString(targetAarray));
		System.out.println("=====================================");
		
		//배열 copy
		System.arraycopy(srcArray, 0, targetAarray, 0, srcArray.length);
		

		System.out.println("Copy이후 데이터");
		System.out.println(Arrays.toString(srcArray));
		System.out.println(Arrays.toString(targetAarray));
		
		//배열 초기화
		for(int i = 0; i < targetAarray.length; i++) {
			targetAarray[i] = 0;
		}
		System.out.println(Arrays.toString(targetAarray));
		
		//배열 copy 활용 : srcArray[2]부터, targetAarray[2]로 
		//srcArray[2]부터 3개 copy
		System.arraycopy(srcArray, 2, targetAarray, 2, 3);
		System.out.println(Arrays.toString(targetAarray));
		
		
		
	}
}


//srciArray[0]=1
//srciArray[1]=2
//srciArray[2]=3
//srciArray[3]=4
//srciArray[4]=5
//Copy전 데이터
//[1, 2, 3, 4, 5]
//[0, 0, 0, 0, 0, 0]
//=====================================
//Copy이후 데이터
//[1, 2, 3, 4, 5]
//[1, 2, 3, 4, 5, 0]
//[0, 0, 0, 0, 0, 0]
//[0, 0, 3, 4, 5, 0]
