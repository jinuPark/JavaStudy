package com.pcwk.ehr.ed02;

public class Buyer {
	int money = 5_000; // 소유 금액
	int bonusPoint = 0; // 보너스 포인트
	Product[] item = new Product[10]; // 구입한 제품을 저장
	int i = 0; // 구입한 제품 Computer

	public Buyer() {
		super();
	}

	/**
	 * 구매 제품 요약 : 구매한 제품 list, 총 구매 금액(sum)
	 */
	void summary() {
		int sum = 0;
		; // 구매 제품 합계
		String itemList = ""; // 제품 목록
		for (int i = 0; i < item.length; i++) {
			if (null == item[i]) {
				break;
			}
			sum += item[i].price;
			itemList += item[i] + ",";
		}
		System.out.printf("구매 총 금액 : %d만원입니다%n", sum);
		System.out.printf("구매한 제품은 %s입니다.", itemList);
	}

	/**
	 * 제품 구매
	 * 
	 * @param p
	 */
	void buy(Product p) {
		if (p.price > money) {
			System.out.println("잔액이 부족합니다.%n잔액을 확인 하세요");
			return;
		}
		money = money - p.price; // money -= p.price;
		bonusPoint += p.bonusPoint; // 제품의 보너스 점수를 추가한다.
		item[i++] = p; // Product[]에 제품 저장
		System.out.println(p + " 구입 완료.");
	}
}