package com.pcwk.ehr.ed04;

public class AudioPlayer extends Player {

	@Override
	void play(int post) {
		System.out.println("AudioPlayer:play()"+post);
		
	}

	@Override
	void stop() {
		System.out.println("AudioPlayer:stop()");

	}


}
