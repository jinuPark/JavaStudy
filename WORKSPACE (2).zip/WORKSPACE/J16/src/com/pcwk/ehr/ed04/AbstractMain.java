package com.pcwk.ehr.ed04;

public abstract class AbstractMain {
	
	public static void main(String[] args) {
		//Cannot instantiate the type Player
		Player player = new AudioPlayer();

		player.play(22);
		player.disp();
		player.stop();

	}

}
