package com.pcwk.ehr.ed03;

public class PolyArgumentMain {

	public static void main(String[] args) {
		Buyer b = new Buyer();
		
		Computer c = new Computer();
		Audio a = new Audio();
		Tv t = new Tv();
		
		b.buy(c);
		b.buy(a);
		b.buy(t);
		//b.buy(new Computer());
		//b.buy(new Audio());
		//b.buy(new Tv());
		b.summary();
		System.out.println("보너스 점수" + b.bonusPoint+"만원 입니다.");
		System.out.println("=======================");
		b.refund(a);
		b.summary();
		System.out.println("보너스 점수" + b.bonusPoint+"만원 입니다.");
		
		
//		System.out.println("===================================");
//		System.out.println("잔액" + b.money+"만원 입니다.");
//		System.out.println("보너스 점수" + b.bonusPoint+"만원 입니다.");

	}

}