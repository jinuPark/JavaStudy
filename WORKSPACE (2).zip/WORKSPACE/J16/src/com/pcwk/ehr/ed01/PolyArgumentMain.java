package com.pcwk.ehr.ed01;

public class PolyArgumentMain {

	public static void main(String[] args) {
		Buyer b = new Buyer();
		
		b.buy(new Computer());
		b.buy(new Audio());
		
		
		System.out.println("===================================");
		System.out.println("잔액" + b.money+"만원 입니다.");
		System.out.println("보너스 점수" + b.bonusPoint+"만원 입니다.");
	}

}