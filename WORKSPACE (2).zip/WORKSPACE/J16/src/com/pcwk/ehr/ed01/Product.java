package com.pcwk.ehr.ed01;

public class Product {
	int price;		// 제품 가격
	int bounsPoint;	// 제품 구매시 제공하는 보너스 점수 : 10%
	
	public Product(int price) {
		this.price = price;
		bounsPoint = (int)(price/10.0);
	}
}