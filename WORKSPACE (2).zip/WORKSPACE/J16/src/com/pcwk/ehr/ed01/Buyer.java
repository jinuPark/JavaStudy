package com.pcwk.ehr.ed01;

public class Buyer {
	int money = 5_000;	// 소유 금액
	int bonusPoint = 0;	// 보너스 포인트
	
	public Buyer() {
		super();
	}
	
	void buy(Product p) {
		if(money < p.price) {
			System.out.println("잔액이 부족합니다.\n잔액을 확인 하세요");
			return;
		}
		
		money -= p.price; // money = money - p.price;
		bonusPoint += p.bounsPoint; // 제품의 보너스 점수를 추가한다.
		
		System.out.println(p + "을/를 구입했습니다.");
	}

	
}

//Computer을/를 구입했습니다.
//Audio을/를 구입했습니다.
//잔액3000만원 입니다.
//보너스 점수200만원 입니다.