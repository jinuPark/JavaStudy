package com.pcwk.ehr.ed01;

public class Tv extends Product {

	public Tv() {
		super(1000);	// Tv 가격을 1000만원으로 한다.
	}

	@Override
	public String toString() {
		return "Tv";
	}

	
}