package com.pcwk.ehr.ed05;

public class Dropship extends Unit {

	@Override
	void move(int x, int y) {
		System.out.printf("Dropship 이동x=%d, y=%d\n", x, y);
	}
	
	void load() {
		System.out.println("Dropship load\n");
	}
	
	void unload() {
		System.out.println("Dropship unload\n");
	}
}