package com.pcwk.ehr.ed05;

public class Marine extends Unit {

	@Override
	void move(int x, int y) {
		System.out.printf("Marine 이동x=%d, y=%d\n", x, y);
	}
	
	void stimPack() {
		System.out.println("stimPack 사용!");
	}
	
	

}