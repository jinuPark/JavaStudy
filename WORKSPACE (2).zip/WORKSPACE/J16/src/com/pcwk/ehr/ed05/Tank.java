package com.pcwk.ehr.ed05;

public class Tank extends Unit {

	@Override
	void move(int x, int y) {
		System.out.printf("Tank 이동x=%d, y=%d\n", x, y);
	}
	
	void changeMode() {
		System.out.println("Tank changeMode\n");
	}
	

}
