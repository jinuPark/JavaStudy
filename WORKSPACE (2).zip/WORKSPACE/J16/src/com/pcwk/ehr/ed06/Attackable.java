package com.pcwk.ehr.ed06;

public interface Attackable {
	void attack(Unit u);
}
