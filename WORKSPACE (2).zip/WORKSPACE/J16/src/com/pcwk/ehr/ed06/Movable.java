package com.pcwk.ehr.ed06;

public interface Movable {
	public abstract void move(int x, int y);

}
