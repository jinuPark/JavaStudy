package com.pcwk.ehr.ed06;

public class Unit {
	int currentHP; // 유닛의 체력
	int x;	// 유닛의 좌표 x
	int y;	// 유닛의 좌표 y
}
