package com.pcwk.ehr.ed06;

//public class Fighter extends Unit implements Attackable, Movable {
public class Fighter extends Unit implements Fightable {
	
	@Override
	public void attack(Unit u) {
		
	}

	public void move(int x, int y) {
		
	}

}
