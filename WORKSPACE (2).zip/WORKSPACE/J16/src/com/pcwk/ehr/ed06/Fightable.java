package com.pcwk.ehr.ed06;

public interface Fightable extends Attackable, Movable{
	// void move(int x, int y);
	
}
