package com.pcwk.ehr.ed03;

public class MyMathMain {

	public static void main(String[] args) {
		MyMath mm = new MyMath();
		
		long result01 = mm.add(14L, 12L);
		long result02 = mm.substract(14L, 12L);
		long result03 = mm.multyply(14L, 12L);
		double result04 = mm.devide(14.0, 12.0);
		
		System.out.printf("add(14L, 12L)=%d\n", result01);
		System.out.printf("substract(14L, 12L)=%d\n", result02);
		System.out.printf("multyply(14L, 12L)=%d\n", result03);
		System.out.printf("devide(14.0, 12.0)=%f\n", result04);

	}

}


//add(14L, 12L)=26
//substract(14L, 12L)=2
//multyply(14L, 12L)=168
//devide(14.0, 12.0)=1.166667

