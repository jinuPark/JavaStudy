package com.pcwk.ehr.ed03;

public class MyMath {

	//return 문이 제어문마다 올 수 있다.
	long max(long x, long y) {
		if( x > y ) {
			return x;
		}
		// return ; 문장은 보통 자동추가되어 타입이 안맞으므로 else 추가해주어야함
		// if 밖 리턴문은 void임.
		else {
			return y;
		}
	}
	
	
	void printDisp() {
		System.out.println("return문이 없다.");
		
		//return; 컴파일러가 추가해 준다.
	}

	/**
	 * 더하기
	 * @param x
	 * @param y
	 * @return x + y
	 */
	long add(long x, long y) {
		long reslut = x + y;
		
		return reslut; // return x+y
	}
	/**
	 * 빼기
	 * @param x
	 * @param y
	 * @return x - y
	 */	
	long substract(long x, long y) {
		long reslut = x - y;
		
		return reslut; // return x-y
	}
	/**
	 * 곱하기
	 * @param x
	 * @param y
	 * @return x * y
	 */
	long multyply(long x, long y) {
		long reslut = x * y;
		
		return reslut; // return x*y
	}

	double devide(double x, double y) {
		double reslut = x / y;
		
		return reslut; // return x/y
	}

}
