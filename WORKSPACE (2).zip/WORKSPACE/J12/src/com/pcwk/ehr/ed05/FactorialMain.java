package com.pcwk.ehr.ed05;

public class FactorialMain {

	public static void main(String[] args) {
//		수학에서, 자연수의 계승 또는 
//		팩토리얼(階乘, 문화어: 차례곱, 영어: factorial)은 
//		그 수보다 작거나 같은 모든 양의 정수의 곱이다.
		// 5! -> 5 * 4 * 3 * 2 * 1
		int result = factorial(5);

		System.out.println("5!="+result);
	}
	
	static int factorial(int n) {
		int result = 0;
		
		if(n == 1) {
			result = 1;
		} else {
			result =  n * factorial(n-1);
		}
		
		return result;
	}

}


// 5!=120

