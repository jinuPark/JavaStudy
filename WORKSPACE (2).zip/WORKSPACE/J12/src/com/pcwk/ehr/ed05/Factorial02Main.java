package com.pcwk.ehr.ed05;

public class Factorial02Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int result = factorial(12);
		System.out.println("12 !="+result);
	}
	
	static int factorial(int n) {
		// int +- 20억
		// 탈출 조건 누락 : Exception in thread "main"
		// java.lang.StackOverflowError
		if(n <=0 || n > 12) {
			return -1;
		}
		
		if( n == 1) {
			return 1;
		}
		
		return n * factorial(n-1);
	}

}
