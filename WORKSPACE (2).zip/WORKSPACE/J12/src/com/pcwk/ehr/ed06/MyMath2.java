package com.pcwk.ehr.ed06;

public class MyMath2 {

		long x;
		long y;

		// 인스턴스 변수 x, y만을 이용해서 작업하므로 매개변수 불필요.
		long add() { return x+y; }
		long substract() { return x-y; }
		long multiply() { return x*y; }
		double devide() { return x/(double)y; }

		
		// static 메서드 : 인스턴스 변수와 관계없이 매개변수 만으로 작업 가능
		
		static long add(long x, long y) { return x+y; }
		static long substract(long x, long y) { return x-y; }
		static long multiply(long x, long y) { return x*y; }
		static double devide(long x, long y) { return x/(double)y; }
		
}
