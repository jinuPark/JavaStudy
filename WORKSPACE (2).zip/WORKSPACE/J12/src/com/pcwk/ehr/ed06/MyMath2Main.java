package com.pcwk.ehr.ed06;

public class MyMath2Main {

	public static void main(String[] args) {
		// 인스턴스 생성
		MyMath2 mm2 = new MyMath2();
		mm2.x = 14;
		mm2.y = 12;
		
		// 인스턴스 메서드는 인스턴스 생성 이후 호출 가능
		System.out.println("mm2.add()="+mm2.add());
		System.out.println("mm2.substract()="+mm2.substract());
		System.out.println("mm2.multiply()="+mm2.multiply());
		System.out.println("mm2.devide()="+mm2.devide());

		// 클래스 메서드 : 인스턴스 생성없이 사용 가능
		System.out.println("MyMath2.add(14, 12)="+MyMath2.add(14, 12));
		System.out.println("MyMath2.add(14, 12)="+MyMath2.substract(14, 12));
		System.out.println("MyMath2.add(14, 12)="+MyMath2.multiply(14, 12));
		System.out.println("MyMath2.add(14, 12)="+MyMath2.devide(14, 12));
		
		
	}

}

//mm2.add()=26
//mm2.substract()=2
//mm2.multiply()=168
//mm2.devide()=1.1666666666666667
//MyMath2.add(14, 12)=26
//MyMath2.add(14, 12)=2
//MyMath2.add(14, 12)=168
//MyMath2.add(14, 12)=1.1666666666666667

