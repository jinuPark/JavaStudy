package com.pcwk.ehr.ed07;

public class OverloadingMain {

	public static void main(String[] args) {
		MyMath3 mm3=new MyMath3();
		System.out.println(mm3.add(14, 12));
		System.out.println(mm3.add(14, 12L));
		System.out.println(mm3.add(14L, 12));

	}

}
//int add(int x, int y) -26
//int add(int x, long y) -26
//long add(long x, int y) -26