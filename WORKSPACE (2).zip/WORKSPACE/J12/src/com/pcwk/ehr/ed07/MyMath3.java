package com.pcwk.ehr.ed07;

public class MyMath3 {

	int add(int x, int y) {
		System.out.println("int add(int x, int y) -");
		return x+y;
	}
	
//	int add(int a, int b) {
//		System.out.println("int add(int x, int y) -");
//		return x+y;
//	}
	
	long add(int x, long y) {
		System.out.println("int add(int x, int y) -");
		return x+y;
	}
	
	long add(long x, int y) {
		System.out.println("long add(long x, int y) -");
		return x+y;
	}


}
//mm2.add()=26
//mm2.substract()=2
//mm2.multiply()=168
//mm2.devide()=1.1666666666666667
//MyMath2.add(14, 12)=26
//MyMath2.add(14, 12)=2
//MyMath2.add(14, 12)=168
//MyMath2.add(14, 12)=1.1666666666666667

