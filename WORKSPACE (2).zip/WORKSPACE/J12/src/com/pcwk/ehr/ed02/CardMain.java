package com.pcwk.ehr.ed02;

public class CardMain {
	public static void main(String[] args) {
		// 클래스 변수: 클래스명.변수명
		System.out.println("Card.width"+Card.width);
		System.out.println("Card.height"+Card.height);
		
		// 인스턴스 변수
		Card c1 = new Card();
		c1.kind = "Heart";
		c1.number = 7;
		
		
		Card c2 = new Card();
		c2.kind = "Spade";
		c2.number = 4;
		
		// 인스턴스 변수 : 공유 안됨, 클래스 변수 : 공유
		System.out.printf("c1은 c1.kind=%s, c1.number=%d"
				+ ", wdth=%d, height=%d\n", c1.kind, c1.number, c1.width, c1.height);

		System.out.printf("c2은 c2.kind=%s, c2.number=%d"
				+ ", wdth=%d, height=%d\n", c2.kind, c2.number, c2.width, c2.height);
			
		System.out.println("width, height의 값을 50, 130으로 변경");
		c1.width = 50;
		c1.height = 130;
		
		System.out.printf("c1은 c1.kind=%s, c1.number=%d"
				+ ", wdth=%d, height=%d\n", c1.kind, c1.number, c1.width, c1.height);

		System.out.printf("c2은 c2.kind=%s, c2.number=%d"
				+ ", wdth=%d, height=%d\n", c2.kind, c2.number, c2.width, c2.height);

	}

}
