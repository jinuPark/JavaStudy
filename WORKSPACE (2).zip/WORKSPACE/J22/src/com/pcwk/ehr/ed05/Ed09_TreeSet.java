package com.pcwk.ehr.ed05;
import java.util.*;

public class Ed09_TreeSet {

	public static void main(String[] args) {
		TreeSet<Integer> treeSet = new TreeSet<Integer>();
		
		// 요소 추가
		System.out.println(treeSet.add(3));
		System.out.println(treeSet.add(3));
		treeSet.add(1);
		treeSet.add(3);
		treeSet.add(2);
		
		// 중복 제거와 sort(ASC)
		System.out.println(treeSet);

	}

}


//true
//false
//[1, 2, 3]

