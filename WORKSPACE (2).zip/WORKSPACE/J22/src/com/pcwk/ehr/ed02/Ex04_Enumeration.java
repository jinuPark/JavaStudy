package com.pcwk.ehr.ed02;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import com.pcwk.ehr.cmn.PLogger;

public class Ex04_Enumeration implements PLogger{
	
	public static void main(String[] args) {
		String[] names = {"Alice", "이상무", "김수환무","Bod", "Charlie"};
		
		Vector<String> nameList = new Vector<String>();
		
		//요소 추가
		for(String name : names) {
			nameList.add(name);
		}
		LOG.debug(nameList);
		
		//Vector를 이용해 Enumeration생성
		Enumeration<String> enume = nameList.elements();
		
		//Enumeration를 Vector에 들어 있는 데이터를 순회하면서 추출
		while(enume.hasMoreElements() == true) {
			String name = enume.nextElement();
			LOG.debug("name:"+name);
			
		}
		
	}

}


// [Alice, 이상무, 김수환무, Bod, Charlie]
// name:Alice
// name:이상무
// name:김수환무
// name:Bod
// name:Charlie

