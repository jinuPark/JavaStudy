package com.pcwk.ehr.ed02;

import java.util.ArrayList;
import java.util.Iterator;

import com.pcwk.ehr.cmn.PLogger;

public class Ex03_Iterator implements PLogger{
	
	public static void main(String[] args) {
		String[] names = {"Alice", "이상무", "김수환무","Bod", "Charlie"};
		
		ArrayList<String> nameList = new ArrayList<String>();
		
		for(String name : names) {
			nameList.add(name);
		}
		LOG.debug(nameList);
		
		//ArrayList를 이용해 Iterator생성
		Iterator<String> iter = nameList.iterator();
		
		//Iterator를 ArrayList에 들어 있는 데이터를 순회하면서 추출
		while(iter.hasNext() == true) {
			String name = iter.next();
			LOG.debug("name:"+name);
			
		}
		
	}

}


// [Alice, 이상무, 김수환무, Bod, Charlie]
// name:Alice
// name:이상무
// name:김수환무
// name:Bod
// name:Charlie
