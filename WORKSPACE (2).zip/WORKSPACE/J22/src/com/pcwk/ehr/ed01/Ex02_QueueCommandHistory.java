package com.pcwk.ehr.ed01;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

import com.pcwk.ehr.cmn.PLogger;

public class Ex02_QueueCommandHistory implements PLogger {

	static final int MAX_SIZE = 5;

	public static void main(String[] args) {
		// 명령어 History 크기 : 5
		// Scanner통한 입력
		// Quit입력 하면 프로그램 종료
		// history를 입력 하면 History 명령 출력

		Queue<String> history = new LinkedList<String>();

		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.print(">>");
			String command = scanner.nextLine();

			history.add(command);

			// 명령어가 5개 이상이면 가장 먼저 들어온 Command 삭제
			if (history.size() > MAX_SIZE) {
				System.out.println("삭제 명령어:" + history.remove());
			}

			if (command.equalsIgnoreCase("quit")) {
				System.out.println("프로그램 종료!");
				break;
			} else if (command.equalsIgnoreCase("history")) {

				System.out.println(history);
			}

		}

	}

}

//>>cd ..
//>>dir
//>>cls
//>>history
//[cd .., dir, cls, history]
//>>mkdir pcwk
//>>cd user
//삭제 명령어:cd ..
//>>history
//삭제 명령어:dir
//[cls, history, mkdir pcwk, cd user, history]
//>>quit
//삭제 명령어:cls
//프로그램 종료!

