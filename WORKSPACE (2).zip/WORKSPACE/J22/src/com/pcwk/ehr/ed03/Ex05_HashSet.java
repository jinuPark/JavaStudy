package com.pcwk.ehr.ed03;

import com.pcwk.ehr.cmn.PLogger;
import java.util.*;

public class Ex05_HashSet implements PLogger{
	
	//HashSet 생성
	public static void main(String[] args) {
		
		String[] names = {"Alice", "이상무", "Alice", "김수환무","Bod", "Alice", "Charlie"};

		//HashSet 생성
		Set<String> set = new HashSet<String>();
		
		//요소 추가
		for(String name: names) {
			set.add(name);
		}
		
		
		//[이상무, Alice, Bod, Charlie, 김수환무]
		LOG.debug(set);
		
		// 요소 삭제
		set.remove("김수환무");
		LOG.debug(set);
		
		// 요소 사이즈
		int size = set.size();
		LOG.debug("set 사이즈:"+size);
	}


}

// [이상무, Alice, Bod, Charlie, 김수환무]
// [이상무, Alice, Bod, Charlie]
// set 사이즈:4