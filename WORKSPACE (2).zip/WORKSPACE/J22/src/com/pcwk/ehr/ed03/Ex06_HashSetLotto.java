package com.pcwk.ehr.ed03;

import com.pcwk.ehr.cmn.PLogger;
import java.util.*;

public class Ex06_HashSetLotto implements PLogger{
	
	public static void main(String[] args) {
		
		Set<Integer> set = new HashSet<Integer>();
		for(int i = 0; set.size() < 6; i++) {
			//0.0 <= x < 1.0
			//0.0 <= x < 45.0
			//0 <= x < 45
			int num = (int)(Math.random() * 45) +1;
			System.out.println("num:"+num);
			set.add(num);
		}
		
		//sort : set을 List로 전환
		List<Integer> list = new LinkedList<Integer>(set);
		Collections.sort(list);
		
		
		// 모든 요소를 하나씩 접근해 출력
		//Iterator<Integer> iter = set.iterator();
		Iterator<Integer> iter = list.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		
	}


}

//num:26
//num:16
//num:4
//num:3
//num:3
//num:37
//num:11
//3
//4
//11
//16
//26
//37

