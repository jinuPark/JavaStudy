package com.pcwk.ehr.ed03;

import java.util.HashSet;

public class Ex07_HashSetEquals {

	public static void main(String[] args) {
		HashSet set = new HashSet();

		set.add("java");
		set.add("java");
		
		Person p01 = new Person("Alice", 21);
		Person p02 = new Person("Alice", 21);

		set.add(p01);
		set.add(p02);
		
		
		System.out.println(set);
	}

}

//[java, Person [name=Alice, age=21], Person [name=Alice, age=21]]
