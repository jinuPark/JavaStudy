package com.pcwk.ehr.ed06;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Ed16_DBProperties {

	public static void main(String[] args) {
		Properties properties = new Properties();
		
		FileInputStream fileInput = null;
		
		String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J22\\src\\com\\pcwk\\ehr\\ed06\\db_config.properties";
		
		try {
			fileInput = new FileInputStream(filePath);
			
			properties.load(fileInput);
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("IOException");
			e.printStackTrace();
		}finally {
			if(null != fileInput ) {
				try {
					fileInput.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
		String dbUsername = properties.getProperty("db.username");
		String dbPassword = properties.getProperty("db.password");//
		String dbURL = properties.getProperty("db.url");

		System.out.println("dbUsername:"+dbUsername);
		System.out.println("dbPassword:"+dbPassword);
		System.out.println("dbURL"+dbURL);
	}

}

//dbUsername:myuser
//dbPassword:mypassword
//dbURLjdbc:oracle:thin:@192.168.0.123:1521:xe

