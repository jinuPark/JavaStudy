package com.pcwk.ehr.ed06;

import java.util.Enumeration;
import java.util.Properties;

public class Ed15_Properties {

	public static void main(String[] args) {
		//Properties 객체 생성
		Properties prop = new Properties();
		
		//key, value 저장
		prop.setProperty("timeout", "30");
		prop.setProperty("language", "kr");
		prop.setProperty("size", "10");
		prop.setProperty("capacity", "10");

		//properties의 모든 요소 출력
		Enumeration<?> enumeration = prop.propertyNames();
		
		while(enumeration.hasMoreElements()) {
			//String element = (String)enumeration.nextElement();//key element 추출
			String key = (String)enumeration.nextElement();//key element 추출
			String value = prop.getProperty(key);//key값으로 vale 추출
			//System.out.println("element:"+element);
			System.out.println(key+": "+value);
			
		}
		//값 변경
		prop.setProperty("size", "20");
		System.out.println("size:"+prop.getProperty("size"));
		
		System.out.println("===================================");
		//시스템 속성:
		Properties sysProp = System.getProperties();
		//시스템 속성중 java.version
		System.out.println("java.version:"+sysProp.getProperty("java.version"));

		// 시스템 속성 내용 모두 출력
		sysProp.list(System.out);
	
	}

}

//capacity: 10
//size: 10
//timeout: 30
//language: kr
//size:20
//===================================

