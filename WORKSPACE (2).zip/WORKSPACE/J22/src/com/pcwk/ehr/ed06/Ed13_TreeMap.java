package com.pcwk.ehr.ed06;

import java.util.TreeMap;

import com.pcwk.ehr.cmn.PLogger;

public class Ed13_TreeMap implements PLogger {

	public static void main(String[] args) {
		// 사 과(10kg)	: 35_189
		// 배			: 32_336
		// 킹크랩			: 210_000
		// 대 하			: 10_000
		
		TreeMap<String, Integer> treeMap=new java.util.TreeMap<String, Integer>();
		
		// 요소 추가
		treeMap.put("사과", 35_189);
		treeMap.put("배", 32_336);
		treeMap.put("킹크랩", 210_000);
		treeMap.put("대하", 10_000);
		
		// 값 가져오기
		int king = treeMap.get("킹크랩");
		LOG.debug("king:"+king);
		
		
		System.out.println(treeMap);
		//{대하=10000, 배=32336, 사과=35189, 킹크랩=210000}

		//요소 순회 (정렬된 순서로 출력)
		for(String key : treeMap.keySet()) {
			//System.out.println(key);
			int value = treeMap.get(key);
			System.out.println(key+","+value);
		}
		
		
	}

}

//[2023-10-12 14:30:34] DEBUG Ed13_TreeMap.main(Ed13_TreeMap.java:25) - king:210000
//{대하=10000, 배=32336, 사과=35189, 킹크랩=210000}
//대하,10000
//배,32336
//사과,35189
//킹크랩,210000
