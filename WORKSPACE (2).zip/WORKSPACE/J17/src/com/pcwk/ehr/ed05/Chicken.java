package com.pcwk.ehr.ed05;

public class Chicken {
	
	public void eat() {
		System.out.println("치킨을 먹습니다.");
	}

}
