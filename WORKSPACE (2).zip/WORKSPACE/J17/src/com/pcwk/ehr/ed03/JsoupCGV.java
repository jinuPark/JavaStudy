package com.pcwk.ehr.ed03;

import java.io.IOException;

//Jsoup
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JsoupCGV {
	
	public static void main(String[] args) {
		
		String url = "http://www.cgv.co.kr/movies/?lt=1&ft=0";
		final int VIEW_MOVIES = 11;
		
		try {
			Document doc = Jsoup.connect(url).get();// url html문서 get
			System.out.println(doc.toString());
			
			// div : html
			//class="box-contents" : .box-contents
			//' ' : html 태그와 태그 구분자
			//class="title": .title
			
			
			
			Elements titles = doc.select("div.box-contents strong.title");//제목

			// div : html태그
			//class="score"
			//strong : html태그
			//class="percent"
			//span : html태그
			Elements reservRTO = doc.select("div.score strong.percent span");//예매율
			
			Elements openDate = doc.select("span.txt-info strong");//개봉일
			
			//class="box-image"
			//class="thumb-image"
			Elements poster = doc.select("div.box-image span.thumb-image img");//포스터
			
			
			for(int i = 0; i < VIEW_MOVIES; i++) {
				Element titleElement = titles.get(i);

				Element reservElement = reservRTO.get(i);
				
				Element openDateElement = openDate.get(i);
				
				String openDateStr = openDateElement.text().replace("개봉", "");
				
				
				//<img src="https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87407/87407_320.jpg" alt="30일 포스터" onerror="errorImage(this)">
				String posterURL = poster.get(i).attr("src"); //속성. img태그에 들어있는 src 속성 값을 선택
				
				System.out.println( (i+1) +"."+titleElement.text()+
						",\t예매율:"+reservElement.text()+
						",\t개봉일:"+openDateStr+
						",\t포스터:"+posterURL);
			}
			
		} catch(IOException e) {
			System.out.println("------------------------------");
			System.out.println(e.getMessage());
			System.out.println("------------------------------");
		}
		
		System.out.println("------------------------------");
		System.out.println("프로그램 종료");
		System.out.println("------------------------------");

	}

}


//1.30일,	예매율:25.7%,	개봉일:2023.10.03 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87407/87407_320.jpg
//2.크리에이터,	예매율:13.9%,	개봉일:2023.10.03 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87354/87354_320.jpg
//3.사나-저주의 아이,	예매율:13.9%,	개봉일:2023.10.04 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87355/87355_320.jpg
//4.화사한 그녀,	예매율:11.6%,	개봉일:2023.10.11  D-7,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87305/87305_320.jpg
//5.천박사 퇴마 연구소-설경의 비밀,	예매율:9.0%,	개봉일:2023.09.27 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87335/87335_320.jpg
//6.거미집,	예매율:5.6%,	개봉일:2023.09.27 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87395/87395_320.jpg
//7.1947 보스톤,	예매율:5.1%,	개봉일:2023.09.27 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87388/87388_320.jpg
//8.화란,	예매율:4.0%,	개봉일:2023.10.11  D-7,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87408/87408_320.jpg
//9.더 넌 2,	예매율:1.4%,	개봉일:2023.09.27 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87387/87387_320.jpg
//10.그란 투리스모,	예매율:1.2%,	개봉일:2023.09.20 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87232/87232_320.jpg
//11.아이유 콘서트 : 더 골든 아워,	예매율:1.1%,	개봉일:2023.09.13 ,	포스터:https://img.cgv.co.kr/Movie/Thumbnail/Poster/000087/87246/87246_320.jpg
//------------------------------
//프로그램 종료
