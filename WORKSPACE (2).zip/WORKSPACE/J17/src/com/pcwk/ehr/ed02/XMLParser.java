package com.pcwk.ehr.ed02;

public class XMLParser implements Parseable{
	
	@Override
	public void parse(String fileName) {
		/* XML 파싱 코드를 기록 */
		System.out.println(fileName + " XML parsing completed");
		
	}

}
