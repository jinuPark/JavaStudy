package com.pcwk.ehr.ed02;

public interface Parseable {
	public abstract void parse(String fileName);
}
