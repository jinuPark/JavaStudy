package com.pcwk.ehr.ed02;

public class JSONParser implements Parseable {

	@Override
	public void parse(String fileName) {
		/* JSON 구문 분석 코드 작성 */
		System.out.println(fileName + " JSON parsing completed");

	}

}
