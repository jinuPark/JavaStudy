package com.pcwk.ehr.ed06;

public class Chicken implements Food {

	@Override
	public void eat() {
		System.out.println("치킨을 먹습니다.");
	}
}