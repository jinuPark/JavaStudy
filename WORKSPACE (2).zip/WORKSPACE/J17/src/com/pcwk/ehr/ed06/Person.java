package com.pcwk.ehr.ed06;

public class Person {
	Food  food;
	Chicken chicken;
	
	public Person(Food  food) {
		this.food = food;
	}
	
	public void startEat() {
		food.eat();
	}
	
}