package com.pcwk.ehr.ed06;

public class FoodMain {

	public static void main(String[] args) {
		Chicken  chicken=new Chicken();
		Pizza    pizza=new Pizza();
		
		Person person=new Person(chicken);
		person.startEat();//치킨을 먹습니다.
		
		
		person=new Person(pizza);
		person.startEat();//포테이토 피자를 먹습니다.

	}

}