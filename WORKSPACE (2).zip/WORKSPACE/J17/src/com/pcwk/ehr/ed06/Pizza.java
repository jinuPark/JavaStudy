package com.pcwk.ehr.ed06;

public class Pizza implements Food {

	@Override
	public void eat() {
		System.out.println("포테이토 피자를 먹습니다.");
	}
}