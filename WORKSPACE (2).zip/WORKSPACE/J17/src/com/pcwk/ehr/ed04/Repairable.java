package com.pcwk.ehr.ed04;

public interface Repairable {

}
