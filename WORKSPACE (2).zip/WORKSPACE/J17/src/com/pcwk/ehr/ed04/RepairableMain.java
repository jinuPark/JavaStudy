package com.pcwk.ehr.ed04;

public class RepairableMain {

	public static void main(String[] args) {
		Tank tank = new Tank();
		Dropship dropship = new Dropship();
		//Repairable 인터페이스를 상속 받지 않음
		Marine marine = new Marine();
		
		SCV scv = new SCV();
		
		scv.repair(tank);
		scv.repair(dropship);
		
		//scv.repair(marine);
		
		
	}

}

//Tank의 수리가 완료되었습니다.
//Dropship의 수리가 완료되었습니다.

