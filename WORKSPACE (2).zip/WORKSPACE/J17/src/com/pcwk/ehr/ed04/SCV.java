package com.pcwk.ehr.ed04;

public class SCV extends GroundUnit implements Repairable{

	SCV() {
		super(60);
		hitPoint = MAX_HP;
	}
	
	@Override
	public String toString() {
		return "SCV";
	}
	
	public void repair(Repairable r) {
		if( r instanceof Unit) {
			
			Unit u = (Unit)r;
			// System.out.println("수리전 u.hitPoint:"+u.hitPoint);
			
			while(u.hitPoint != u.MAX_HP) {
				u.hitPoint++; // Unit의 체력을 증가 시킨다.
			}
			
			// System.out.println("수리후 u.hitPoint:"+u.hitPoint);
			System.out.println(u.toString()+"의 수리가 완료되었습니다.");
			
		}
	}
	
	
	

}
