package com.pcwk.ehr.ed01;

public class Tv {
	protected int volume;
	protected int channel;
	protected boolean power;
	
	public void power() {
		power = !power;
	}
	
	public void channelUp() {
		channel++;
	}
	
	public void channelDown() {
		channel--;
	}
	
	public void volumeUp() {
		volume++;
	}
	
	public void volumeDown() {
		volume--;
	}
}
