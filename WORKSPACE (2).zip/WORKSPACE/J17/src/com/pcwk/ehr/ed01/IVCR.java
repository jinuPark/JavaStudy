package com.pcwk.ehr.ed01;

public interface IVCR {

	public abstract void play();

	void stop();

	void reset();

	/**
	 * @return the counter
	 */
	int getCounter();

	/**
	 * @param counter the counter to set
	 */
	void setCounter(int counter);

}