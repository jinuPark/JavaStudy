package com.pcwk.ehr.ed09;

public class Animal {
	public String bark() {
		return "동물이 웁니다.";
	}

}
