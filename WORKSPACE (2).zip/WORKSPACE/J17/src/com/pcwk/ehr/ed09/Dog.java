package com.pcwk.ehr.ed09;

public class Dog extends Animal {

	@Override
	public String bark() {
		return "개가 짖습니다.";
	}
}
