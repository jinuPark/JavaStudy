package com.pcwk.ehr.ed07;

public class Parent {
	
	public void disp() {
		System.out.println("disp() is Parent ");
	}
}
