package com.pcwk.ehr.ed07;

public interface PcwkInter {
	//추상 메서드
	void regularMethod();

	/**
	 * default키워드 사용시 일반메서드처럼 body 부분을 생설할 수 있다.
	 */
	default void pcwkDefaultMethod() {
		System.out.println("pcwkDefaultMethod() is Pcwkinter");
	}
	
	/**
	 * static키워드 사용시 일반메서드처럼 body 부분을 생설할 수 있다.
	 */
	static void pcwkStaticMethod() {
		System.out.println("pcwkStaticMethod() is Pcwkinter");
	}
	
}
