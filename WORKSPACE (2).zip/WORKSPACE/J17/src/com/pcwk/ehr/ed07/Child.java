package com.pcwk.ehr.ed07;

public class Child extends Parent implements PcwkInter{

	@Override
	public void regularMethod() {
		System.out.println("child regularMethod()");
	}
	
	public void pcwkDefaultMethod() {
		System.out.println("pcwkStaticMethod() is child");
	}

}
