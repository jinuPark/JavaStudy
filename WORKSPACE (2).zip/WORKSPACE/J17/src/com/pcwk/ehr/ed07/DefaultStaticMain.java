package com.pcwk.ehr.ed07;

public class DefaultStaticMain {
	
	public static void main(String[] args) {
		Child child = new Child();
		//default메서드 오버라이딩
		child.pcwkDefaultMethod();
		
		//추상메서드 오버라이딩
		child.regularMethod();
		
		//static메서드 호출
		PcwkInter.pcwkStaticMethod();
	}

}
