package com.pcwk.ehr.ed01;
import java.util.Calendar;


public class Ex03_CalenarSet {

	public static void main(String[] args) {
		//Calendar 객체 생성
		Calendar cal = Calendar.getInstance();
		
		//2024년 11월 마지막 날짜
		cal.set(Calendar.YEAR, 2024);
		cal.set(Calendar.MONTH, 10);//cal.set(Calendar.MONTH, Calendar.NOVEMBER);
		
		int lastDayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		System.out.println("lastDayOfMonth:"+lastDayOfMonth);//30
		cal.set(Calendar.DAY_OF_MONTH,lastDayOfMonth);
		
		
		System.out.println(toDateString(cal));
	}
	
	/***
	 * 형식에 맞춘 날짜
	 * @param cal
	 * @return 2024년 11월 30일
	 */
	public static String toDateString(Calendar cal) {
		String formatDate = "";
		
		formatDate = cal.get(Calendar.YEAR)+"년"+(cal.get(Calendar.MONTH)+1)+"월"+cal.get(Calendar.DAY_OF_MONTH);
		
		
		return formatDate;
	}

}
//lastDayOfMonth:30
//2024년11월30

