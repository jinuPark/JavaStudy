package com.pcwk.ehr.ed01;
import java.util.Calendar;

public class Ex04_CalendarAdd {

	public static void main(String[] args) {
		//0 년월일 입력 받기
		int year = 0;//년도
		int month = 0;//월

		try {
		String yearString  = args[0];
		String monthString = args[1];

		System.out.println("년도:"+yearString);
		System.out.println("월:"+monthString);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("년도와 월을 입력 하세요. ex)2023 10");
			System.out.println(e.getMessage());
			//프로그램 종료: 0이면 정상 종료, 그외 값은 비정상 종료, -1비정상 종료 
			System.exit(0);
		}
		
	}
	
}
