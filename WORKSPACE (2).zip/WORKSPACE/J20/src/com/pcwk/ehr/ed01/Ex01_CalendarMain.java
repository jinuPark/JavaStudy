package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;
import java.util.Calendar;

public class Ex01_CalendarMain implements PLogger {

	public static void main(String[] args) {
		Calendar toDay01 = Calendar.getInstance();
		
		LOG.debug("========================================");
		//toDay01.get(field) : 출력하고 싶은 날짜 시간 상수를 파람으로 전달
		//Calendar.Year = 1
		LOG.debug("년도:"+toDay01.get(Calendar.YEAR));//Calendar.YEAR = 1
		LOG.debug("월:"+(toDay01.get(Calendar.MONTH)+1));//1월 : 0부터 시작 11까지
		LOG.debug("일:"+(toDay01.get(Calendar.DATE)));
		
		//요일(1~7) : 1(일요일)
		LOG.debug("요일:"+toDay01.get(Calendar.DAY_OF_WEEK));//요일:3: 화요일
		
		LOG.debug("========================================");
		//오전:0, 오후:1
		LOG.debug("오전:0, 오후:1->"+toDay01.get(Calendar.AM_PM));
		
		//시간 
		LOG.debug("시간(0~11)"+toDay01.get(Calendar.HOUR));// 0 - 11
		LOG.debug("시간(0~23)"+toDay01.get(Calendar.HOUR_OF_DAY));//0-23
		
		//분
		LOG.debug("분(0~59)"+toDay01.get(Calendar.MINUTE));
		//초
		LOG.debug("분(0~59)"+toDay01.get(Calendar.SECOND));
		
		//1/1000초
		LOG.debug("1/1000초"+toDay01.get(Calendar.MILLISECOND));
		
	}

}
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:11) - ========================================
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:14) - 년도:2023
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:15) - 월:10
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:16) - 일:10
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:19) - 요일:3
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:21) - ========================================
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:23) - 오전:0, 오후:1->0
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:26) - 시간(0~11)10
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:27) - 시간(0~23)10
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:30) - 분(0~59)37
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:32) - 분(0~59)55
//[2023-10-10 10:37:55] DEBUG Ex01_CalendarMain.main(Ex01_CalendarMain.java:35) - 1/1000초469