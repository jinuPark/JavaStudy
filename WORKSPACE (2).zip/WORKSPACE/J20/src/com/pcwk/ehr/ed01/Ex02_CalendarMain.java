package com.pcwk.ehr.ed01;
import java.util.Calendar;

import com.pcwk.ehr.cmn.PLogger;

public class Ex02_CalendarMain implements PLogger{

	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance();
		
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH)+1;//1월달이 0부터 시작+1
		int day	= calendar.get(Calendar.DAY_OF_MONTH);

		LOG.debug("현재 날짜는 "+year+"년"+month+"월"+day+"일");
		LOG.debug("=====================================");
		//요일 : 일요일(1) ~ 토요일 (7)
		//		(1~7) -1
		//		(0~6) 
		String[] dayOfWeekStr = {"일","월","화","수","목","금","토"};
		int dayOfweek = calendar.get(Calendar.DAY_OF_WEEK);
		String dayOfWeekString = dayOfWeekStr[dayOfweek-1];
		LOG.debug("요일:"+dayOfWeekString);
		//LOG.debug("현재 요일은 "+year+"년"+month+"월"+day+"일");
		
	}

}

//[2023-10-10 11:09:01] DEBUG Ex02_CalendarMain.main(Ex02_CalendarMain.java:15) - 현재 날짜는 2023년10월10일
//[2023-10-10 11:09:01] DEBUG Ex02_CalendarMain.main(Ex02_CalendarMain.java:16) - =====================================
//[2023-10-10 11:09:01] DEBUG Ex02_CalendarMain.main(Ex02_CalendarMain.java:23) - 요일:화

