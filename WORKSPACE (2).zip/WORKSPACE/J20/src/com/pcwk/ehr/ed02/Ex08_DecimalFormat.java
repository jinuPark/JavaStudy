package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;
import java.text.DecimalFormat;

public class Ex08_DecimalFormat implements PLogger {

	public static void main(String[] args) {

		double num = 12345.6789;
//		LOG.debug("num=>"+num);//num=>12345.6789
//		0 : 숫자를 나타내는 자릿수 (없으면 0으로 채움)
//		# : 숫자를 나타내는 자릿수 (없으면 표시하지 않음)
//		, : 그룹 구분 기호 (숫자를 천 단위로 그룹화)
//		. : 소수점 구분 기호
//		- : 음수 기호
//		% : 백분율로 표시
//		E : 지수 표기법 사용 (과학적 표기법)
//		기타 : 기호 및 문자 등을 포함하여 원하는 형식 지정 가능
		
		
		// 숫자를 일반 숫자 형식으로 포맷
		//DecimalFormat decimalFormat = new DecimalFormat("000000.00"); //000000.00 =>012345.68
		//DecimalFormat decimalFormat = new DecimalFormat("0,000.00");
		DecimalFormat decimalFormat = new DecimalFormat("0.00"); 
		LOG.debug("0.00 =>"+decimalFormat.format(num));//0.00 =>12345.68 : 소수점 3째자리에서 반올림
		
		// 숫자, 천 단위 구분기호, 소수점 두 자리
		DecimalFormat groupedFormat = new DecimalFormat("#,###.00");
		LOG.debug("숫자 천단위 구분 기호:"+groupedFormat.format(num));//숫자 천단위 구분 기호:12,345.68
		
		// 숫자를 백분율로 표시
		DecimalFormat percentFormat = new DecimalFormat("0.00%");
		LOG.debug("숫자를 백분율로:"+percentFormat.format(num));//1234567.89%
		
		// 통화 출력
		DecimalFormat currFormat = new DecimalFormat("\u00A4#,###.##");
		LOG.debug("통화 :"+currFormat.format(num));//통화 :￦12,345.68

		// $통화 출력
		DecimalFormat dFormat = new DecimalFormat("$#,###.##");
		LOG.debug("통화 :"+dFormat.format(num));//통화 :$12,345.68

	}

}
