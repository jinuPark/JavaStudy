package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;
import java.text.MessageFormat;

public class Ex10_MessageFormater implements PLogger {

	public static void main(String[] args) {
		// 데이터 입력 sql생성
		
		String tableName = "board";
		//INSERT INTO BOARD VALUES (1,'제목1','내용1','2023-10-10');
		String msg       = "INSERT INTO "+tableName+" VALUES({0}, ''{1}'', ''{2}'', ''{3}'');";
		
		Object[][] boardData = {
				{1,"제목1","내용1","2023-10-10"},
				{2,"제목2","내용2","2023-10-11"},
				{3,"제목3","내용4","2023-10-12"}
		};
		
		System.out.println("boardData.length:"+boardData.length);
		
		MessageFormat mf=new MessageFormat(msg);
		
		for(int i=0;i<boardData.length;i++) {
			LOG.debug(mf.format(boardData[i]));
		}
		
	}

}
//INSERT INTO board VALUES(1, '제목1', '내용1', '2023-10-10');
//INSERT INTO board VALUES(2, '제목2', '내용2', '2023-10-11');
//INSERT INTO board VALUES(3, '제목3', '내용4', '2023-10-12');