package com.pcwk.ehr.ed09;

public class Parent {
	public int age = 22;
	
	public void pcwkMethod() {
		System.out.println("Parent pcwkMethod()");
	}
}
