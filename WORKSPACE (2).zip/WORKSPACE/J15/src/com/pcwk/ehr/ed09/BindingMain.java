package com.pcwk.ehr.ed09;

public class BindingMain {


	public static void main(String[] args) {
		Parent p = new Child();
		
		//Parent p.x:22
		System.out.println("p.x:"+p.age);
		p.pcwkMethod();	// overriding : Child pcwkMethod()

		System.out.println("==================");
		
		Child c = new Child();
		//c.age:12
		System.out.println("p.x:"+c.age);
		c.pcwkMethod();	// overriding : Child pcwkMethod()
		
	}

}
