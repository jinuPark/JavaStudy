/**
 * Package Name : com.pcwk.ehr.ed06 <br/>
 * Class Name: PolymorphismMain.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed06;


public class PolymorphismMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Tv t = new CaptionTv();// 조상 타입의 참조변수로 자손 인스턴스 참조
		CaptionTv caption = new CaptionTv();
		
		CaptionTv c02 = (CaptionTv)new Tv();
		
	}

}
