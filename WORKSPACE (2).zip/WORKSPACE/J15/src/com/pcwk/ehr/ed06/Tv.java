package com.pcwk.ehr.ed06;

public class Tv {
	
	/**
	 * 전원 on/off
	 */
	boolean power;	// 전원 상태(on/off)
	int channel;	// 채널
	
	void power() {
		power = !power; // true->false, false->true
	}
	
	/**
	 *  채널 Up
	 */
	void channelUp() {
		++channel;
	}

	/**
	 *  채널 Down
	 */
	void channelDown() {
		--channel;
	}
}
