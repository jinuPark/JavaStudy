
package com.pcwk.ehr.ed02;

/**
 * Package Name : com.pcwk.ehr.ed02 <br/>
 * Class Name: TimeMain.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
public class TimeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Time time = new Time();
		time.setHour(11);
		time.setMinute(59);
		time.setSecond(55);
		
		
		System.out.println("time:"+time);// time:com.pcwk.ehr.ed02.Time@15db9742

		// time:Time [hour=11, minute=35, second=55, toString()=com.pcwk.ehr.ed02.Time@15db9742]
		// time02:Time [hour=11, minute=35, second=57, toString()=com.pcwk.ehr.ed02.Time@6d06d69c]

		Time time02 = new Time(11,35,57);
		System.out.println("time02:"+time02);
	}

}
