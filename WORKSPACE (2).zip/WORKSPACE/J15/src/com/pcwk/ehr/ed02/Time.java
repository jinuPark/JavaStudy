package com.pcwk.ehr.ed02;

/**
 * Package Name : com.pcwk.ehr.ed02 <br/>
 * Class Name: Time.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */

public class Time {
	// alt + shift + a : 새로 편집
	
	//TimeMain.java만들고 Time 객체 생성후 . 눌러보면 안보임
	//private 지우면보임
	private int hour; 	// 시간(0<=x<=23)
	private int minute; // 분(0<=x<=59)
	private int second; // 초(0<=x<=59)
//	int hour; 	// 시간(0<=x<=23)
//	int minute; // 분(0<=x<=59)
//	int second; // 초(0<=x<=59)
	
	
	public Time() {	// (defalut) 생성자 는 다른패키지에서 안보이므로 public으로 주기
		super();
	}
	
	
	public Time(int hour, int minute, int second) {
		super(); //Object 생성자
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}


	/**
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}


	/**
	 * @param hour the hour to set
	 */
	public void setHour(int hour) {
		if(!(hour >= 0 && hour <= 59)) {	// (hour<0 || hour>59)
			return;
		}
		this.hour = hour;
	}


	/**
	 * @return the minute
	 */
	public int getMinute() {
		return minute;
	}


	/**
	 * @param minute the minute to set
	 */
	public void setMinute(int minute) {
		if(!(minute >= 0 && minute <= 59)) {	// (minute<0 || minute>59)
			return;
		}
		this.minute = minute;
	}


	/**
	 * @return the second
	 */
	public int getSecond() {
		return second;
	}


	/**
	 * @param second the second to set
	 */
	public void setSecond(int second) {
		if(minute >= 0 && minute <= 59) {
			return;
		}
		this.second = second;
	}
	
	@Override
	public String toString() {
		return "Time [hour=" + hour + ", minute=" + minute + ", second=" + second + ", toString()=" + super.toString()
				+ "]";
	}

}
