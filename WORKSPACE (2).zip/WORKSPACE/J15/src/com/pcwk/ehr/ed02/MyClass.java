/**
 * Package Name : com.pcwk.ehr.ed02 <br/>
 * Class Name: MyClass.java <br/>
 * Description: 캡슐화 <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed02;

/**
 * @author user
 *
 */
public class MyClass {

	private int age; // private 필드

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}


	

}
