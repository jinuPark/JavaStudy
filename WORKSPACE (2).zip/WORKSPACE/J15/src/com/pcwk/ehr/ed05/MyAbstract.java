package com.pcwk.ehr.ed05;
/**
 * Package Name :  <br/>
 * Class Name: MyAbstract.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */

/**
 * @author user
 *
 */
public abstract class MyAbstract {		// 추상 클래스

	abstract void myAbstractMethod();	// 추상 메서드

	
}
