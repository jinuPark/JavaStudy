package com.pcwk.ehr.ed08;

import com.pcwk.ehr.ed07.Car;
//import com.pcwk.ehr.ed07.*;
import com.pcwk.ehr.ed07.FireEngine;

//ctrl+shift+f : 소스 정리
//ctrl+shift+o : import정리

public class InstanceOfOperationMain {

	public static void main(String[] args) {
		//Car car;
		FireEngine fe = new FireEngine();
		
		//참조변수 instanceof 타입(클래스명)
		System.out.printf("fe instanceof FireEngine=%b\n", (fe instanceof FireEngine));

		if (fe instanceof FireEngine) {
			System.out.println("This is a FireEngine instance");
		}
		System.out.println("-------------------------------");
		
		System.out.printf("fe instanceof Car=%b\n", (fe instanceof Car));
		if (fe instanceof Car) {
			System.out.println("This is a Car instance");
		}
		System.out.println("-------------------------------");
		
		System.out.printf("fe instanceof Object=%b\n", (fe instanceof Object));
		if (fe instanceof Object) {
			System.out.println("This is a Object instance");
		}
		
		//FireEngine / Amulance
//		System.out.printf("fe instanceof Ambulance=%b\n", (fe instanceof Ambulance));
//		if (fe instanceof Ambulance) {
//			System.out.println("This is a Ambulance instance");
//		
//		}
		
	}

}


//fe instanceof FireEngine=true
//This is a FireEngine instance
//-------------------------------
//fe instanceof Car=true
//This is a Car instance
//-------------------------------
//fe instanceof Object=true
//This is a Object instance

