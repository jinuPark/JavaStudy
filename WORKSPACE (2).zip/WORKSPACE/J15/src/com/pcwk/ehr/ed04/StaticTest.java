/**
 * Package Name : com.pcwk.ehr.ed04 <br/>
 * Class Name: StaticTest.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed04;

/**
 * @author user
 *
 */
public class StaticTest {
	static { // 클래스 초기화 블럭
		
	}

	static int width = 200;	// 클래스 변수
	
	static int max(int a, int b) { // 클래스 메서드
		return a>b?a:b;
	}
	
}
