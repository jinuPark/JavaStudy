/**
 * Package Name : com.pcwk.ehr.ed07 <br/>
 * Class Name: RefCastingMAin.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed07;

/**
 * @author user
 *
 */
public class RefCastingMAin {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Car car = null;
		FireEngine fe = new FireEngine();
		
		fe.warter();
		// 자손 타입 -> 조상 타입(Up-casting) : 형변환 생략 가능
		car = fe;	// 형변환 생략 가능
		//car.warter(); // 오류 : The method warter() is undefined for the type Car
		
		FireEngine fe02 = null;
		
		// 조상 타입 -> 자손 타입(Down-casting) : 형변환 생략 불가
		fe02 = (FireEngine)car;	// 형변환 생략 불가
		fe02.warter();
	}

}
