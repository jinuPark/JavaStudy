/**
 * Package Name : com.pcwk.ehr.ed07 <br/>
 * Class Name: FireEngine.java <br/>
 * Description: <br/>
 * Modification imformation :
 * ------------------------------------------
 * 최초 생성일 : 2023.09.26
 *
 * ------------------------------------------
 * author : user
 * since  : 2023.09.07
 * version: 0.5
 * see    : <br/>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed07;

/**
 * @author user
 *
 */
public class FireEngine extends Car {

	
	
	void warter() {
		System.out.println("water!!");
	}
}
