package com.pcwk.ehr.ed07;

public class Car {
    private String color;
    private int door;

    public void drive(){
    	System.out.println("운전");
    }

    public void stop(){
    	
    }

}
