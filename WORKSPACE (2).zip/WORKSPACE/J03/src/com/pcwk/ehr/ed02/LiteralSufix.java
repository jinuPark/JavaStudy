package com.pcwk.ehr.ed02;

public class LiteralSufix {

	public static void main(String[] args) {

		 //int age = 80L; // 
		long age = 80L; //  L/1 접미사 사용
		
		// 실수형
		float pi = 3.14f;
		double rate = 1.144D;
		
		
	}

}
