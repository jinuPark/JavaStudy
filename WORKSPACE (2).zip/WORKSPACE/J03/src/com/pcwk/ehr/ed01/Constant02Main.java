package com.pcwk.ehr.ed01;

public class Constant02Main {

	public static void main(String[] args) {
		final int WIDTH = 20; // 폭
		final int HEIGHT = 10; // 높이
		
		int triangleArea = (WIDTH * HEIGHT) / 2;
		
		System.out.println("triangleArea="+triangleArea);
	}

}
