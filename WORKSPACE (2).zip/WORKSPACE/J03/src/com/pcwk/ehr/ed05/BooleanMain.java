package com.pcwk.ehr.ed05;

public class BooleanMain {

	public static void main(String[] args) {
		boolean power;
		power = true;
		
		boolean checked = false;

		System.out.printf("power=%b%n", power);
		//System.out.println(power);
		System.out.printf("checked=%b%n", checked);
	}

}
