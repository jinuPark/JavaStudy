package com.pcwk.ehr.ed06;

public class Parent {
	int num;
	
	Parent(int num) {
		this.num = num;
	}
}
