package com.pcwk.ehr.ed02;

public class Triangle extends Shape {
	Point[] point = new Point[3];	// 점 3개

	public Triangle(Point[] point) {
		this.point = point;
	}

	void draw() {
		System.out.printf("[p1=%s, p2=%s, p3=%s]%n", point[0].getXY(), point[1].getXY(), point[2].getXY() );
	}
	
	
}
