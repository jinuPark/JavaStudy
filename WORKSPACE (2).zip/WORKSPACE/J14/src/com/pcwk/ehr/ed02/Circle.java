package com.pcwk.ehr.ed02;

public class Circle extends Shape {
	Point center;	// 원점(x, y)
	int r;			// 반지름 

	public Circle() {
		this(new Point(0,0),100);
	}
	
	public Circle(Point center, int r) {
		this.center = center;
		this.r = r;
	}

	void draw() {	// 원의 원점과, 반지름, 색상
		System.out.printf("[center=(%d, %d)], r=%d, color=%s ] %n ", 
				center.x, center.y, r, color);
	}
	

}
