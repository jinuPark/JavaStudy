package com.pcwk.ehr.ed02;


/***
 * 좌표 클래스
 * @author user
 *
 */
public class Point {

	int x;	// 좌표 x
	int y;	// 좌표 y
	
	Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Point () {
		this(0, 0);	// 인자 2개의 생성자 호출
	}
	
	/***
	 * x,y 좌표 return
	 * @return : String
	 */
	String getXY() {
		return "("+x+","+"y)";
	}
	
	
}
