package com.pcwk.ehr.ed05;

public class SuperMain {
	
	public static void main(String[] args) {
		Child child = new Child();
		child.display();
	}
}


//자식 클래스의 age=12
//부모 클래스의 age=22
