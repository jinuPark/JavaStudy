package com.pcwk.ehr.ed03;

public class Deck {
	final int CARD_NUM = 52; // 카드 개수
	
	Card []cardArray = new Card[CARD_NUM];
	
	Deck() {
		//KIND(4가지):카드 종류, NUMBER(13개)
		
		int i = 0;
		
		for(int k=Card.KIND_MAX; k>0; k--) {
			
			for(int n = 0; n < Card.NUM_MAX; n++) {
				cardArray[i++] = new Card(k,n+1);
			}// --for n
		}// --for k
		
	}// --for Deck() default 생성자
	
	
	/***
	 * 임의의 index에 있는 카드 한장
	 * @param index
	 * @return Card
	 */
	Card pick(int index) {
		return cardArray[index];
	}
	
	/***
	 * top에 카드 한장 추출
	 * @return Card
	 */
	Card pick() {
		//return cardArray[0];
		return pick(0);
		
	}
	
	/**
	 * 카드 섞기
	 */
	void shuffle(){
		
		for(int i = 0; i < cardArray.length; i++) {
			
			// 0.0 <= x < 1.0
			// 0.0 <= x < 52.0
			// 0 <= x < 52
			int r = (int)(Math.random() * CARD_NUM);//0.0<=x<1.0
			
			
			//Card 배열의 자리 교환
			Card temp	 = cardArray[i];
			cardArray[i] = cardArray[r];
			cardArray[r] = temp;
					
			
		}	// -- for i
	}	// -- shuffle
	
}
