package com.pcwk.ehr.ed01;

public class CaptionTv extends Tv {

	boolean caption; // 캡션 on/off
	
	void displayCaption(String text) {
		
		if(caption) {// 캡션 on때 자막 출력
			System.out.println(text);	// 클래스 이름은 대문자로 시작하고, 그 다음 단어의 첫 글자 대문자로 표시한다. 
		}
	}
	
}
