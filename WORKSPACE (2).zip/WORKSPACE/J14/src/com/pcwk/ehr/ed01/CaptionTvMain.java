package com.pcwk.ehr.ed01;

public class CaptionTvMain {

	public static void main(String[] args) {
		CaptionTv captionTv = new CaptionTv();
		
		captionTv.power(); // 전원 on
		
		captionTv.channel = 3; 	// tvN
		captionTv.channelUp();
		
		System.out.println(captionTv.channel);
		System.out.println(captionTv.power);

		System.out.println("caption");
		System.out.println("Hello, world!");

	}

}
//4
//true
//caption
//Hello, world!
