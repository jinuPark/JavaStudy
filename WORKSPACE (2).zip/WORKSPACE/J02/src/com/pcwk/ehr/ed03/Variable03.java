/**
 * Date : 2023. 9. 8.
 * File Name : Variable03.java
 * 사용자 : hbi1
 */
package com.pcwk.ehr.ed03;

/**
 * @author hbi1
 *
 */
public class Variable03 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int newAge;// 변수는 카멜캐이스
		int newage;//

		boolean True;
		// boolean true; 예약어로 사용할 수 없음

		int top100;
		// int 10top; 숫자로 시작해서는 안 된다.

		int $shape; // 특수문자는 ‘_’, ‘$’만을 허용한다.
		int _shape;
		// int #shape;

		int 이상무 = 22; // 한글 변수 사용가능 : 단 현장에서 사용하지 않음!
		System.out.println(이상무);

	}// ctrl+shift+f

}
