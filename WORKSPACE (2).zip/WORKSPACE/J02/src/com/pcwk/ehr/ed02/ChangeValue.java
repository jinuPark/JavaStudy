/**
 * Date : 2023. 9. 8.
 * File Name : ChangeValue.java
 * 사용자 : hbi1
 */
package com.pcwk.ehr.ed02;

/**
 * @author hbi1
 *
 */
public class ChangeValue {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 변수의 값 교환 : x = 14, y = 12
		int x = 12;
		int y = 14;
		int tmp = 0;

		System.out.println("변수의 값 교환 이전");
		System.out.println("x="+x);
		System.out.println("y="+y);
		
		tmp = x;
		x   = y;
		y   = tmp;
		System.out.println("변수의 값 교환 이후");
		System.out.println("x="+x);
		System.out.println("y="+y);
		

	}

}
