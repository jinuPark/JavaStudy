package com.pcwk.ehr.ed02;

import java.util.Scanner;

public class Ed11_If_elseif_else {

	public static void main(String[] args) {
		// 1. 성적을 입력 받아,
		// 2. 학점을 출력
		
		int score = 0;		// 성적
		char grade = ' ';	// 학점
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("성적을 입력 하세요.>");
		score = scanner.nextInt();
		System.out.printf("score=%d%n", score);

		if(score >= 90) {
			grade = 'A';
			System.out.println("성적은 A입니다.");
		} else if (score >= 80) {	// 80<=score && score<90 : 위 에서 아래로 조건 비교하면 내려 온다. 'score >= 80'
			grade = 'B';
			System.out.println("성적은 B입니다.");
		} else if (score >= 70) {	
			grade = 'C';
			System.out.println("성적은 C입니다.");
		} else if (score >= 60) {	
			grade = 'D';
			System.out.println("성적은 D입니다.");
		} else {
			grade = 'F';
			System.out.println("성적은 F입니다.");
		}

		System.out.printf("score=%d, grade=%c%n", score, grade);
	}

}


//성적을 입력 하세요.>88
//score=88
//성적은 B입니다.score=88, grade=B
