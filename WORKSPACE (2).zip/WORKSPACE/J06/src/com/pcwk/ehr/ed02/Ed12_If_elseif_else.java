package com.pcwk.ehr.ed02;

import java.util.Scanner;

public class Ed12_If_elseif_else {

	public static void main(String[] args) {
		// 1. 성적을 입력 받아,
		// 2. 학점을 출력
		
		int score	 = 0;		// 성적
		char grade	 = ' ';	// 학점
		char opt	 =	' ';// + -
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("성적을 입력 하세요.>");
		score = scanner.nextInt();
		System.out.printf("score=%d%n", score);

		if(score >= 90) {
			grade = 'A';
			
			if(score >= 95) {
				opt = '+';
			}else {
				opt = '-';
			}
			
			System.out.println("성적은 A입니다.");
		} else if (score >= 80) {	// 80<=score && score<90 : 위 에서 아래로 조건 비교하면 내려 온다. 'score >= 80'
			grade = 'B';			
			if(score >= 85) {
				opt = '+';
			}else {
				opt = '-';
			}
		} else if (score >= 70) {	
			grade = 'C';			
			if(score >= 75) {
				opt = '+';
			}else {
				opt = '-';
			}
		} else if (score >= 60) {	
			grade = 'D';
			if(score >= 65) {
				opt = '+';
			}else {
				opt = '-';
			}
		} else {
			grade = 'F';
			System.out.println("성적은 F입니다.");
		}

		System.out.printf("score=%d, grade=%c%c%n", score, grade, opt);
	}

}


