package com.pcwk.ehr.ed02;

public class Ed09_If {

	public static void main(String[] args) {
		// if 조건문
		// 특정 조건을 만족하면 수행할 작업을 정해놓고, 만족하면 수행!
		
		int age = 23;
		System.out.printf("age>20 \t %b%n", age > 20);
		
		if(age > 20) {
			System.out.println("it교육을 배운다.");
			System.out.println("it교육을 배운다.");
			System.out.println("it교육을 배운다.");
			System.out.println("it교육을 배운다.");
			System.out.println("it교육을 배운다.");
			
		}//--if
		
		System.out.println("프로그램 종료!");
		
		
	}

}


//age>20 	 true
//it교육을 배운다.
//it교육을 배운다.
//it교육을 배운다.
//it교육을 배운다.
//it교육을 배운다.
//프로그램 종료!
