package com.pcwk.ehr.ed02;

import java.util.Scanner;

public class Ed10_If_else {

	public static void main(String[] args) {
		/*
		*  1. console로 문자 입력
		*  2. 입력 받은 문자를 판단 : 소문자 여부 판단
		*/
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("문자 하나를 입력 하세요.>");
		
		String input = scanner.nextLine();
		System.out.printf("input = %s%n", input);
		
		char ch = input.charAt(0); // 문자열 중에 첫 번째 위치에 char 잘라내기
		System.out.printf("ch=%c%n", ch);
		
		if('a'<=ch && ch<='z') {
			System.out.println("입력한 문자는 영문 소문자 입니다.");
		} else {
			System.out.println("입력한 문자는 영문 소문자가 아닙니다.");
		}
		
		System.out.println("프로그램 종료!");
	}

}
