package com.pcwk.ehr.ed01;

public class Ed06_NotOperator {

	public static void main(String[] args) {
			boolean bValue  =  true;
			char ch			= 'C';
			
			System.out.printf("bValue=%b%n", bValue);			
			System.out.printf("!bValue=%b%n", !bValue);
			System.out.printf("!bValue=%b%n", !!bValue);
			
			System.out.println("========================");
			System.out.printf("ch=%c%n", ch);
			
			System.out.println(ch <'a' || ch > 'z');
			
			System.out.println( !('a' <= ch && ch <='z'));
	}

}


//bValue=true
//!bValue=false
//!bValue=true
//========================
//ch=C
//true
//true

