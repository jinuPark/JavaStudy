package com.pcwk.ehr.ed01;

public class Ed07_ShiftOperator {

	public static void main(String[] args) {
		int num01 = 8;
		// 좌 쉬프트
		int result = num01 << 2;
		
		System.out.println("num01 = "+num01);
		System.out.println("result = "+result);
		
		//우 쉬프트
		num01 = 8;
		result = num01 >> 2;
		
		System.out.println("num01 = "+num01);
		System.out.println("result = "+result);
		
		

	}

}

//num01 = 8
//result = 32
//num01 = 8
//result = 2

