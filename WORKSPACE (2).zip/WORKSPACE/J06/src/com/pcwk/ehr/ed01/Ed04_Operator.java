package com.pcwk.ehr.ed01;

import java.util.Scanner;

//import java.util.Scanner;

public class Ed04_Operator {

	public static void main(String[] args) {
		// console통해 문자 하나를 입력 받는다.
		// 숫자인지 문자인지 판단
		Scanner scanner = new Scanner(System.in);
		
		char ch = ' ';
		System.out.println("문자를 하나 입력 하세요>");
		String input = scanner.nextLine();
		
		System.out.println("input:" +input);
		ch = input.charAt(0);
		System.out.println("ch:" +ch);
		
		// '0' <= ch && ch <= '9'

		if ('0' <= ch && ch <= '9') {
			System.out.println("입력한 문자는 숫자입니다.");
		}
		
		// 'a' <= ch && ch = 'z' || 'A' <= ch && ch = 'Z'
		if (('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z') ){
			System.out.println("입력한 문자는 영문자입니다.");
			
		}
	}

}

//문자를 하나 입력 하세요>
//c
//input:c
//ch:c
//입력한 문자는 영문자입니다.

