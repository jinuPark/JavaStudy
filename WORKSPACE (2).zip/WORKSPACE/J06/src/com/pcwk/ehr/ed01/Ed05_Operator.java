package com.pcwk.ehr.ed01;

public class Ed05_Operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num01 = 10;
		int 	i =  2;
		
		System.out.println("before i : "+i);
		//			      false						&&	  true
		
		boolean flag = ( (num01 = num01 + 10) < 10) && ( (i = i + 2) < 10) ;

		System.out.println("flag : " + flag);
		System.out.println("num01 : " + num01);	//정상 수행 num01 = 20 이 됨
		System.out.println("i : " + i); // 값이 4로 증가되지 않음 (수행되지 않음!)
		

	}

}

//before i : 2
//flag : false
//num01 : 20
//i : 2

