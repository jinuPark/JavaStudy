package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed08_Operator {

	public static void main(String args[]) {
		// 나이에 따라 미성년 여부 판단.
		int age = 22;
		String message = (age >= 18) ? "성인":"미성년";
		System.out.printf("나이=%d, 성인여부:%s%n", age, message);
		


	}

}
//나이=22, 성인여부:성인
