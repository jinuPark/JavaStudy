package com.pcwk.ehr.ed02;

public class Tv {

	//Tv클래스 속성
	String color; // 색상
	boolean power; // 전원상태(on/off)
	int channel; //채널
	
	
	//Tv 클래스의 기능
	void power() {			// Tv전원을 켜거나 끄는 기능의 메서드 on/off
		power = !power;
	}
	
	void channelUp() {		// Tv의 채널을 올리는 기능
		channel++;
	}
	
	void channelDown() {	// Tv의 채널을 내리는 기능
		channel--;
	}
	
}
