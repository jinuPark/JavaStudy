package com.pcwk.ehr.ed02;

public class TvMain03 {

	public static void main(String[] args) {
		// tv01인스턴스 변수와, tv02인스턴스 변수는 서로 영향을 미치지 않는다.
		Tv tv01 = new Tv();	//0x100
		Tv tv02 = new Tv(); //0x200
		
		//멤버 변수는 배열처리 데이터타입의 초기값으로 초기화!
		//int이므로 0으로 초기화
		System.out.println("tv01의 channel 값:"+tv01.channel);
		System.out.println("tv01의 channel 값:"+tv02.channel);
		
		tv02 = tv01;		//0x100주소 공유
		
		tv01.channel = 3;
		System.out.println("tv01의 channel 값 3으로 변경:"+tv02.channel);
		System.out.println("==============================");
		System.out.println("tv01의 channel 값:"+tv01.channel);
		System.out.println("tv01의 channel 값:"+tv02.channel);
	}

}


//tv01의 channel 값:0
//tv01의 channel 값:0
//tv01의 channel 값 3으로 변경:0
//==============================
//tv01의 channel 값:3
//tv01의 channel 값:0
