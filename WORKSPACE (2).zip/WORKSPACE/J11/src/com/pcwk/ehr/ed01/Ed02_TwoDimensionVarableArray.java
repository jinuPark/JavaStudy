package com.pcwk.ehr.ed01;

public class Ed02_TwoDimensionVarableArray {

	public static void main(String[] args) {
		// 가변 배열 생성
		int[][] variableArray = new int[3][];
		
		// 각 행마다 다른 길이의 배열을 할당
		variableArray[0] = new int[] {1, 2, 3};
		variableArray[1] = new int[] {4, 5};
		variableArray[2] = new int[] {6, 7, 8, 9};
		
		for(int i=0; i<variableArray.length; i++) {
			for(int j=0; j<variableArray[i].length; j++) {
				System.out.print(variableArray[i][j]+" ");
			}
			System.out.println();
		}
		
	}

}


//1 2 3 
//4 5 
//6 7 8 9 
