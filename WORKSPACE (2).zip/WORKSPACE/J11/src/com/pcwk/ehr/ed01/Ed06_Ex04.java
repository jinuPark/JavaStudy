package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed06_Ex04 {

	public static void main(String[] args) {
		//행렬의 덧셈
		int[][] A = {
				{1, 2, 3},
				{4, 5, 6}
			};

		int[][] B = {
				{7, 8, 9},
				{10, 11, 12}
		};
		
		int[][] C = new int [2][3];

		System.out.println("A.length:"+A.length);//2
		System.out.println("A[0].length:"+A[0].length);//3
		
		// 덧셈
		for(int i = 0; i < A.length; i++) {
			for(int j = 0; j<A[0].length; j++) {
				//C[i][j] = A[i][j] + B[i][j];
				// 뺴기
				C[i][j] = A[i][j] - B[i][j];
			}
		}

		for(int i = 0; i < A.length; i++) {
			for(int j = 0; j<A[0].length; j++) {
				System.out.println(C[i][j]);
			}
			System.out.println();
		}
	}// --main

}// --class


