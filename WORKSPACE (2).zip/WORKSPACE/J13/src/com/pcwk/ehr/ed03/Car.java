package com.pcwk.ehr.ed03;

public class Car {
	// 멤버변수(인스턴스 변수)
	
	String brand; // 브랜드
	String model; // 모델
	int year; // 연식
	
	
	Car() {
		
	}
	
	Car(String b, String m, int y) {
		brand = b;
		model = m;
		year  = y;
	}
	
	public void startEngine() {
		System.out.println("차량 시동을 겁니다.");
	}
	
	public void stopEngine() {
		System.out.println("차량 시동이 꺼집니다.");
	}
}
