package com.pcwk.ehr.ed02;

public class Data2 {
	int value;
	
// 인자있는 생성자가 1개라도 있으면 default 생성자를
// Data2() {
// 만들어주지 않는다.	
// }
	
	//Data2() {
		
	//}
	Data2(int x) {
		value = x;
	}

}
