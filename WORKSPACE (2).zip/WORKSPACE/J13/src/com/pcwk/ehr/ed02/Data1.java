package com.pcwk.ehr.ed02;

public class Data1 {
	int value;
	
	//dafalut 생성자 만들지 않음

}
