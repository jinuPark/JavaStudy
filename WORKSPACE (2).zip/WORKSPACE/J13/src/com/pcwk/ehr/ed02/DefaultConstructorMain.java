package com.pcwk.ehr.ed02;

public class DefaultConstructorMain {

	public static void main(String[] args) {
		Data1 d1 = new Data1();
		//Data2 d2 = new Data2();// error The constructor Data2 is undefined
		

	}

}
