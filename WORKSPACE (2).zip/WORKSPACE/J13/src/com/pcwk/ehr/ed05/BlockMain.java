package com.pcwk.ehr.ed05;

public class BlockMain {
	static {
		System.out.println("static {}");
	}
	
	{
		System.out.println("{ }");
	}
	public BlockMain() 
	{
		System.out.println("기본 생성자");	
	}

	public static void main(String[] args) {
		BlockMain bm = new BlockMain();
		System.out.println("=========================");	
		

		
		BlockMain bm02 = new BlockMain();
		
	}

}
