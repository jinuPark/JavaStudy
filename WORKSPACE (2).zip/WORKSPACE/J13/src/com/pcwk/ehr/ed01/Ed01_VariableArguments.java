package com.pcwk.ehr.ed01;

public class Ed01_VariableArguments {

	public static void main(String[] args) {
		String[] strArray = {"-", "100", "200", "500"};
		System.out.println(concatenate("-", "100", "200", "300"));
		System.out.println(concatenate("-", strArray));
		System.out.println(concatenate(",", new String[] {"1", "2", "3"}));
		
		// 가변인자는 생략 
		System.out.println("["+concatenate(",")+"]");
		
		System.out.printf("가변인자는 생략 가능");

	}
	
	// 구분자, 가변인자 : -, 100, 200, 300 -> 100-200-300
	/***
	 * 구분자와 가변인자를 결합
	 * @param delim : 구분자
	 * @param args  : 가변인자
	 * @return String
	 */
	static String concatenate(String delim, String... args) {
		String result = "";
		
		//System.out.println(args.length);
		// 가변인자는 배열
		for(String str :args) {
			result += str + delim;
		}
		
		return result;
	}

}
