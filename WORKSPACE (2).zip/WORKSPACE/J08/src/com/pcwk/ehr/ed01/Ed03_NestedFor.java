package com.pcwk.ehr.ed01;

public class Ed03_NestedFor {

	public static void main(String[] args) {
		
		int rows = 5; // 삼각형의 높이
		
		for (int i = rows; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}

}

//*****
//****
//***
//**
//*