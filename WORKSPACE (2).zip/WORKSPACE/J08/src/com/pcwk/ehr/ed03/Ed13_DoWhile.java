package com.pcwk.ehr.ed03;
import java.util.Scanner;

public class Ed13_DoWhile {

	public static void main(String[] args) {
//		1~100사이에 임의의 난수 발생, 이 수를 맞추기
//		수자를 입력하면 크다, 작다, 정답
//		1~100사이 난수
		
		
		// computer 난수 처리 : 1 ~ 3
//		Math.random();					//0.0 <= x < 1.0
//		Math.random() * 100;			//0.0 <= x < 100.0
//		(int)Math.random()() *100;		//0 <= x < 100
//		( (int)Math.random() *100 ) + 1;//1 <= x < 101

		// 1~100사이 난수
		int answer = 0; // 사용자
		int input = 0;	// 사용자 입력변수
		
		answer = (int)(Math.random()*100)+1; //1 <= x < 101
		//System.out.println(answer);
		
		// 사용자 숫자 입력
		Scanner scanner = new Scanner(System.in);
		System.out.println("answer="+answer);
		
		do {
			System.out.print("1~100사이 정수를 입력 하세요.>");
			input = scanner.nextInt();
			
			if(input>answer) {
				System.out.println("더 작은 수를 입력 하세요.");
			} else if(input<answer) {
				System.out.println("더 큰 수를 입력 하세요.");				
			}
			
		} while(input != answer );
		
		System.out.println("정답입니다.");
	}//--main
	
}//--class



