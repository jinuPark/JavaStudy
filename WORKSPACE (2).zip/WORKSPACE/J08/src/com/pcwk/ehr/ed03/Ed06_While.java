package com.pcwk.ehr.ed03;

public class Ed06_While {

	public static void main(String[] args) {
		
		int totalSum = 0; // 합계
		int i = 1; // 증가 변수
		
		while(i <= 100) {
			totalSum += i;
			System.out.println(totalSum+","+i);
			i++;
		}// -- while 끝
		
		System.out.println("totalSum:" + totalSum);
	}

}

//3403,82
//3486,83
//3570,84
//3655,85
//3741,86
//3828,87
//3916,88
//4005,89
//4095,90
//4186,91
//4278,92
//4371,93
//4465,94
//4560,95
//4656,96
//4753,97
//4851,98
//4950,99
//5050,100
//totalSum:5050
