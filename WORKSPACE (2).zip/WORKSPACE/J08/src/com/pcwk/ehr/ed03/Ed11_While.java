package com.pcwk.ehr.ed03;
import java.util.Scanner;

public class Ed11_While {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum = 0; //합계
		int num = 0; //숫자 입력
		Scanner scanner = new Scanner(System.in);
		System.out.println("정수를 입력 하세요(0입력시 프로그램 종료)");

		while( (num = scanner.nextInt())!=0) {
			System.out.println("num="+num);	
			sum+=num; // sum = sum+num

			System.out.print("정수를 입력 하세요(0입력시 프로그램 종료)");
		}//--while

		System.out.printf("총합=%d\n",sum);	
		System.out.println("프로그램 종료!");
		
	}//--main
	
}//--class



//정수를 입력 하세요(0입력시 프로그램 종료)
//1
//num=1
//정수를 입력 하세요(0입력시 프로그램 종료)2
//num=2
//정수를 입력 하세요(0입력시 프로그램 종료)3
//num=3
//정수를 입력 하세요(0입력시 프로그램 종료)5
//num=5
//정수를 입력 하세요(0입력시 프로그램 종료)0
//총합=11
//프로그램 종료!
