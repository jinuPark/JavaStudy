package com.pcwk.ehr.ed03;

import java.util.Scanner;

public class Ed09_WhileToFor {

	public static void main(String[] args) {
		//숫자를 입력(12345), 이 숫자의 각 자리의 합을 구하기.
		//(1+2+3+4+5) = 15
		
		//1. 숫자를 입력 받는다.
		//2. 12345
		// 2.1. 12345 % 10 = 5
		// 2.2. 12345 / 10 = 1234
		
		int totalSum = 0; // 합
		int num 	 = 0; // 입력변수

		// System.out.println(1/10); //0
		// System.out.println(12345 % 10); //5
		// System.out.println(12345 / 10); //1234

		Scanner scanner = new Scanner(System.in);
		System.out.print("숫자를 입력 하세요.(예:12345)");
		num = scanner.nextInt();
		
		System.out.printf("num"+num);
		

	}
	
}

//숫자를 입력 하세요.(예:12345)12345
//num12345