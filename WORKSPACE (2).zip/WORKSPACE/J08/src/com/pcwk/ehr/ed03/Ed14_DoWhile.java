package com.pcwk.ehr.ed03;
import java.util.Random;

public class Ed14_DoWhile {

	public static void main(String[] args) {
		int sum = 0; // 합계
 		int i   = 1; // 증감
 		
 		while(true) { // 무한 loop
 			sum += i;
 			
 			if(sum >= 88) {	// 합계가 88이상이면 벗어남
 				break;
 			}
 			
 			i++;
 		}

 		System.out.printf("sum=%d%n", sum);
 		System.out.printf("i=%d%n", i);
	}//--main
	
}//--class


//sum=91
//i=13
