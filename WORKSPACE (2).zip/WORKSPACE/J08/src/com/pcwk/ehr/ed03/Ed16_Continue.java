package com.pcwk.ehr.ed03;

import java.util.Random;

public class Ed16_Continue {

	public static void main(String[] args) {
		// 1 ~ 10 사이 홀수만 출력!
		
		for(int i = 1; i <= 10; i++) {
			if( i % 2 == 0) {
				continue;
			}
			System.out.println(i);
		}
		System.out.println("프로그램 종료");
	}
}

//1
//3
//5
//7
//9
//프로그램 종료