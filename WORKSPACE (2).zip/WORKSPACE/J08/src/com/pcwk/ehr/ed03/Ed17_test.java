package com.pcwk.ehr.ed03;

import java.util.Random;

public class Ed17_test {

	public static void main(String[] args) {
		// 1+(1+2)+(1+2+3)+(1+2+3+4)+...+(1+2+3+...+10)의 결과를 계산하시오.
		// 220
		
		int sum = 0;
		int totalsum = 0;
		
		// 1  3     6       10
		for(int i = 1; i <= 10; i++) {
			System.out.println("i = "+ i);
			sum = sum + i; // sum += i;
			System.out.println("sum = " + sum);
			totalsum = totalsum + sum;
			System.out.println("totalsum = " + totalsum);
		}
		System.out.println("프로그램 종료");
	}
}
