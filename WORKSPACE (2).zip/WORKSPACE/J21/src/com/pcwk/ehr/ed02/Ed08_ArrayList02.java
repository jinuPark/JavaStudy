package com.pcwk.ehr.ed02;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pcwk.ehr.cmn.PLogger;


public class Ed08_ArrayList02 implements PLogger {
	/***
	 * List 내용을 콘솔에 출력
	 * @param args
	 */
	
	public static void dispList(List<String> list) {
		for(String str :list) {
			LOG.debug(str);
		}
	}
	
	public static void main(String[] args) {
		List nameList = new ArrayList();

		int cnt = 0; // 김씨 인원 count
		
		
		Scanner scanner = new Scanner(System.in);
		while(nameList.size() != 5) {
			System.out.print("이름을 입력 하세요>");
			
			String name = scanner.nextLine();
			
			nameList.add(name);
			LOG.debug(name);
		}

		//ArrrayList에 들어 있는 데이터 출력
		dispList(nameList);
		
		for(int i = 0; i < nameList.size(); i++) {
			String findName = (String) nameList.get(i);
			
			//이름 중 김씨 성을 가진 사람
			if(findName.startsWith("김")) {
				cnt++;
				System.out.println("findname:"+findName);
			}
		}
		LOG.debug("김씨 성을 가진 사람은 "+cnt+"명 입니다.");
	}

}

//이름을 입력 하세요>박진우
//[2023-10-11 16:47:18] DEBUG Ed08_ArrayList02.main(Ed08_ArrayList02.java:35) - 박진우
//이름을 입력 하세요>김지우
//[2023-10-11 16:47:21] DEBUG Ed08_ArrayList02.main(Ed08_ArrayList02.java:35) - 김지우
//이름을 입력 하세요>ㅎㅇ
//[2023-10-11 16:47:23] DEBUG Ed08_ArrayList02.main(Ed08_ArrayList02.java:35) - ㅎㅇ
//이름을 입력 하세요>김신
//[2023-10-11 16:47:26] DEBUG Ed08_ArrayList02.main(Ed08_ArrayList02.java:35) - 김신
//이름을 입력 하세요>김우
//[2023-10-11 16:47:28] DEBUG Ed08_ArrayList02.main(Ed08_ArrayList02.java:35) - 김우
//[2023-10-11 16:47:28] DEBUG Ed08_ArrayList02.dispList(Ed08_ArrayList02.java:18) - 박진우
//[2023-10-11 16:47:28] DEBUG Ed08_ArrayList02.dispList(Ed08_ArrayList02.java:18) - 김지우
//[2023-10-11 16:47:28] DEBUG Ed08_ArrayList02.dispList(Ed08_ArrayList02.java:18) - ㅎㅇ
//[2023-10-11 16:47:28] DEBUG Ed08_ArrayList02.dispList(Ed08_ArrayList02.java:18) - 김신
//[2023-10-11 16:47:28] DEBUG Ed08_ArrayList02.dispList(Ed08_ArrayList02.java:18) - 김우
//findname:김지우
//findname:김신
//findname:김우
//[2023-10-11 16:47:28] DEBUG Ed08_ArrayList02.main(Ed08_ArrayList02.java:50) - 김씨 성을 가진 사람은 3명 입니다.
