package com.pcwk.ehr.ed02;

import java.util.Stack;

import com.pcwk.ehr.cmn.PLogger;

public class Ed13_StackUse implements PLogger{

	public static boolean isBalanced(String expression) {
		boolean isBalanced = false;
		
		//Character를 하나씩 저장
		Stack<Character> stack = new Stack<>();
		
		for(char c : expression.toCharArray()) {
			//LOG.debug(" "+c);
			//여는 괄호가 있으면 스택에 추가,
			//닫는 괄호가 발견되면 스택에 제거
			//stack이 비어 있으면 괄호 일치
			
			if('(' == c || '{' == c || '[' == c || ')' == c || '}' == c || ']' == c) {
				
				//여는 괄호가 있으면 스택에 추가
				if( '(' == c || '{' == c || '[' == c ) {
					stack.push(c);
				} else if ( ')' == c && !stack.isEmpty() && stack.peek() == '(' ) {
					stack.pop();
				} else if ( '}' == c && !stack.isEmpty() && stack.peek() == '{' ) {
					stack.pop();
				} else if ( ']' == c && !stack.isEmpty() && stack.peek() == '[' ) {
					stack.pop();
				} else {
					return false;
				}
				
			}
		}
		
		return isBalanced = stack.isEmpty();
	}
	
	public static void main(String[] args) {
		// ((2+3) *1) + 3

		//String expression = "((2+3) *1) + 3";
		//String expression = "((2+3) *1)) + 3";
		String expression = "{(2+3) *1} + 3";
		
		//isBalanced(expression);
		if(true == isBalanced(expression)) {
			LOG.debug("괄호 일치!");
		} else {
			LOG.debug("괄호 불 일치!");
		}
	}
}
//[2023-10-11 16:29:48] DEBUG Ed13_StackUse.main(Ed13_StackUse.java:51) - 괄호 일치!