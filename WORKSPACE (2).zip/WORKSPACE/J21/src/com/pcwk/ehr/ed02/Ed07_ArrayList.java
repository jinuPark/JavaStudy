package com.pcwk.ehr.ed02;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.pcwk.ehr.cmn.PLogger;

public class Ed07_ArrayList implements PLogger{

	public static void main(String[] args) {
		// ArrayList: 가변 배열
		ArrayList list = new ArrayList(); // 10개의 저장공간 생성

		// 요소 추가 : 순서 보장
		list.add("Pear");
		list.add("Banana");
		list.add("Apple");
		
		// 요소 사이즈:get
		LOG.debug("요소 사이즈:"+list.size());
		
		// 요소 출력: 추가 순서대로 순서 보장
		for(int i = 0; i < list.size(); i++) {
			LOG.debug(list.get(i));
		}
		
		// 요소 수정
		list.set(1, "Watermelon");
		LOG.debug("첫 번째 요소:" + list.get(1));
		
		// 요소 탐색
		if(list.contains("Apple")) {
			LOG.debug("Apple이 있습니다.");
		} else {
			LOG.debug("Apple이 없습니다.");
		}

		
		// sort
		Collections.sort(list);
		
		// sort이후 데이터 출력
		dispList(list);
	}
	
	public static void dispList(List<String> list) {
		for(String str :list) {
			LOG.debug(str);
		}
	}

}


// 요소 사이즈:3
// Pear
// Banana
// Apple
// 첫 번째 요소:Watermelon
// Apple이 있습니다.
// Apple
// Pear
// Watermelon