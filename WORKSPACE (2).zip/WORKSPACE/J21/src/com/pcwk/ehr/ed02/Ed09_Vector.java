package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;
import java.util.Vector;

	public class Ed09_Vector implements PLogger {
		
		/***
		 * Vector size, capacity
		 * @param vector
		 */
		
		public static void dispVector(Vector<String> vector) {
			LOG.debug("vector:"+vector.toString());
			LOG.debug("size:"+vector.size());
			LOG.debug("capacity:"+vector.capacity());
			
		}
		
		public static void main(String[] args) {
			// Vector생성. capacity:10
			//Vector<String> vector = new Vector<String>();
			Vector<String> vector = new Vector<String>(22);
			dispVector(vector); //vector:[]
			
			LOG.debug("========================");
			// 요소 추가
			LOG.debug(vector.add("사과"));//성공적으로 추가되면 true return. size1
			vector.addElement("바나나");//size2
			vector.add("체리");//size3
			
			dispVector(vector); //vector:[사과, 바나나, 체리]
			
			// 요소에 사이즈와 capacticy 같게 처리
			vector.trimToSize();
			dispVector(vector);//size3, capacity:3
			
			// 요소 삭제
			//vector:[사과, 체리]
			vector.removeElement("요소 삭제:"+vector.removeElement("바나나"));
			dispVector(vector);//size2, capacity:3
			
			// 전체 요소에 접근
			//fruit:사과
			//fruit:체리
			for(String fruit :vector) {
				LOG.debug("fruit:"+fruit);
			}
			
		}

		
}

//vector:[]
//size:0
//capacity:22
//========================
//true
//vector:[사과, 바나나, 체리]
//size:3
//capacity:22
//vector:[사과, 바나나, 체리]
//size:3
//capacity:3
//vector:[사과, 체리]
//size:2
//capacity:3
//fruit:사과
//fruit:체리

