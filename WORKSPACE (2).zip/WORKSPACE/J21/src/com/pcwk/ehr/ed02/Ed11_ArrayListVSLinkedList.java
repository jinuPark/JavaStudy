package com.pcwk.ehr.ed02;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.pcwk.ehr.cmn.PLogger;

public class Ed11_ArrayListVSLinkedList implements PLogger{
	/***
	 * 순차적인 추가
	 * @param list
	 * @return
	 */
	public static long sequentialAdd(List list) {
		long start = System.currentTimeMillis();
	
		for(int i=0; i<1_000_000;i++) {
			list.add(i+"");
		}

		long end = System.currentTimeMillis();

		return end - start;
	}
	
	/***
	 * 중간에 추가
	 * @param args
	 */
	public static long middleAdd(List list) {
		long start = System.currentTimeMillis();
	
		for(int i=0; i<10_000;i++) {
			list.add(99, i+"");//list 99번째에 데이터 추가
		}

		long end = System.currentTimeMillis();

		return end - start;
	}
	
	
	// 삭제: List 계열의 삭제는 마지막 부터 삭제
	public static long removeList(List list) {
		long start = System.currentTimeMillis();
// 앞에서 부터 순차적으로 삭제시 원하는 방향으로 삭제 안됨. 이상하게 값이 들어가 있게 됨.
//		for(int i=0; i<100;i++) {
//			list.remove(i);//
//		}

		for(int i=list.size()-1; i >= 100; i--) {
			list.remove(i);
		}
		
		long end = System.currentTimeMillis();

		return end - start;
	}
	
	
	public static void main(String[] args) {
		// 순차적인 추가 삭제
		ArrayList arrayList = new ArrayList();
		LinkedList linkedList = new LinkedList();
		
		//the current time in milliseconds
		//System.out.println(""+System.currentTimeMillis()); //1697005119939
		LOG.debug("순차적인 추가");
		LOG.debug("arrayList:"+sequentialAdd(arrayList));
		LOG.debug("linkedList:"+sequentialAdd(linkedList));

		LOG.debug("====================================");
		LOG.debug("중간에 추가");
		LOG.debug("arrayList:"+middleAdd(arrayList));
		LOG.debug("linkedList:"+middleAdd(linkedList));
		
		LOG.debug("====================================");
		LOG.debug("삭제");
		LOG.debug("arrayList:"+removeList(arrayList));
		LOG.debug("linkedList:"+removeList(linkedList));
		//LOG.debug("arrayList:"+arrayList);
	}

}


// 순차적인 추가
// arrayList:89
// linkedList:636
// ====================================
// 중간에 추가
// arrayList:1186
// linkedList:4

//순차적인 추가
//arrayList:89
//linkedList:662
//====================================
//중간에 추가
//arrayList:1187
//linkedList:18
//====================================
//삭제
//arrayList:0
//linkedList:32
//arrayList:[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 9999]
