package com.pcwk.ehr.ed01;

import java.time.Duration;
import java.time.LocalTime;

public class Ex06_Duration {

	public static void main(String[] args) {
		LocalTime startTime = LocalTime.of(10, 9, 30);
		LocalTime endTime = LocalTime.of(12, 50, 01);

		// 두 시간 간의 차이를 계산
		Duration duration = Duration.between(startTime, endTime);

		System.out.println("시간 간격: " + duration.toHours() + "시간" + duration.toMinutes() + "분 " + duration.toMillis());

		// 특정 시간의 간격 더하기
		LocalTime futureTime = startTime.plus(duration);
		System.out.println("더한 시간:" + futureTime);
	}

}
//시간 간격: 2시간160분 9631000
//더한 시간:12:50:01

