package com.pcwk.ehr.ed01;

import java.time.LocalDate;
import java.time.Period;

public class Ex05_Period {
	//ctrl+shift+f : 소스 정리
	//ctrl+shift+o : import 정리
	public static void main(String[] args) {
		LocalDate startDate = LocalDate.of(2021, 5, 1);
		LocalDate endDate = LocalDate.of(2023, 10, 11);

		// 두 날짜 간에 차이를 계산
		Period period = Period.between(startDate, endDate);

		System.out.println("날짜 간격:" + period.getYears() + "년 " + period.getMonths() + "개월" + period.getDays() + "일");

		// 특정 날짜에 날짜 간격 더하기
		LocalDate futureDate = startDate.plus(period);
		System.out.println("더한 날짜 :" + futureDate);
	}

}
//날짜 간격:2년 5개월10일
//더한 날짜 :2023-10-11
