package com.pcwk.ehr.ed04;

import java.io.FileInputStream;
import java.io.IOException;

public class Ed04_FileInputStream {
	//ctrl+shift+f : 소스 정렬
	//cyrl+shift+o : import 정리
	public static void main(String[] args) {
		// String filePath =
		// "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\src\\com\\pcwk\\ehr\\ed04\\Ed04_FileInputStream.java";
		// C:\JSPM_0907\01_JAVA\WORKSPACE\J25\src\log4j2.properties
		String filePath = args[0];
		System.out.println("filePath:" + filePath);

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filePath);
			int data = 0; // 1byte
			while ((data = fis.read()) != -1) {
				char ch = (char) data;// int 4byte -> char로 casting
				System.out.print(ch);// byte 0 ~ 255 범위의 정수 데이터 이므로 char 형변환
			}

		} catch (IOException e) {
			System.out.println("IOException:" + e.getMessage());
		} finally {
			if (null != fis) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("=======================");
		System.out.println("=End=");
		System.out.println("=======================");

	}

}
