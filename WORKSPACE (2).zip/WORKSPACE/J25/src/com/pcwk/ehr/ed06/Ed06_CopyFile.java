package com.pcwk.ehr.ed06;

import java.io.*;


public class Ed06_CopyFile {

	public static void main(String[] args) {
		if(args.length != 2) {
			System.out.println("원본파일 경로, 저장 파일명을 입력 하세요.");
			System.exit(0);
		}
		//C:\JSPM_0907\01_JAVA\WORKSPACE\J25\src\log4j2.properties copy_log4j2.properties
		//copy_log4j2.properties
		System.out.println("원본 파일:"+args[0]);
		System.out.println("copy 파일:"+args[1]);
		

		try (
			FileInputStream fis = new FileInputStream(args[0]);
			FileOutputStream fos = new FileOutputStream(args[1])) {
			
			int data = 0;
			while( (data=fis.read()) != -1) {//데이터를 1byte read
				fos.write(data);
			}
			
			

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		System.out.println("Copy완료");

	}

}
