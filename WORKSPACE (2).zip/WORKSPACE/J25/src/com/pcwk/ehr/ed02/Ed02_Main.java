package com.pcwk.ehr.ed02;

public class Ed02_Main {

	public static void main(String[] args) {
		RunnableEx r = new RunnableEx();

		//balance가 minus(-)발생 하지 않음!
		new Thread(r).start();
		new Thread(r).start();

	}

}

//[2023-10-17 10:10:25] DEBUG RunnableEx.run(RunnableEx.java:16) - 800
//[2023-10-17 10:10:26] DEBUG RunnableEx.run(RunnableEx.java:16) - 500
//[2023-10-17 10:10:27] DEBUG RunnableEx.run(RunnableEx.java:16) - 200
//[2023-10-17 10:10:27] DEBUG RunnableEx.run(RunnableEx.java:16) - 200
//[2023-10-17 10:10:27] DEBUG RunnableEx.run(RunnableEx.java:16) - 200
//[2023-10-17 10:10:28] DEBUG RunnableEx.run(RunnableEx.java:16) - 0
//[2023-10-17 10:10:28] DEBUG RunnableEx.run(RunnableEx.java:16) - 0
