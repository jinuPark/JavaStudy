package com.pcwk.ehr.ed02;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Counter {
	private int count = 0;
	
	private Lock lock = new ReentrantLock();
	
	public void increment() {
		lock.lock();//락 획득
		try {
			count++;
		}finally {
			lock.unlock();//락 해제:finally에서
		}
	}

}
