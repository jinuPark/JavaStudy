package com.pcwk.ehr.ed07;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ed07_CopyFile {

	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("원본파일 경로, 저장 파일명을 입력 하세요.");
			System.exit(0);
		}
		// C:\JSPM_0907\01_JAVA\WORKSPACE\J25\src\log4j2.properties
		// copy_log4j2.properties
		// copy_log4j2.properties
		// copy_log4j2.properties
		System.out.println("원본 파일:" + args[0]);
		System.out.println("copy 파일:" + args[1]);

		// finally로 자원 반납
		FileInputStream fis = null;
		FileOutputStream fos = null;

		try {
			fis = new FileInputStream(args[0]);
			fos = new FileOutputStream(args[1]);
			int data = 0;
			while ((data = fis.read()) != -1) {// 데이터를 1byte read
				fos.write(data);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			if (null != fis) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if (null != fos) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		System.out.println("Copy완료");

	}

}
