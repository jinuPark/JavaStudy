package com.pcwk.ehr.ed11;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ed11_BufferedReader {

	public static void main(String[] args) {
		//String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\src\\com\\pcwk\\ehr\\ed11\\Ed11_BufferedReader.java";
		String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\src\\launchBox.txt";
		long startTime = System.currentTimeMillis();// 시작 시간
		try(FileReader fr = new FileReader(filePath);
				BufferedReader br = new BufferedReader(fr)) {
			
			String line = "";//데이터 저장용
			
			// br.readLine() : 데이터가 더이상 없으면 null이 return
			while( (line = br.readLine()) != null) {
				System.out.println(line);
			}
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		long endTime = System.currentTimeMillis();//종료시간
		System.out.println("경과시간:"+(endTime - startTime));//경과시간:186
		

	}

}
