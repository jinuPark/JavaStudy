package com.pcwk.ehr.ed05;

import java.io.FileInputStream;
import java.io.IOException;

public class Ed05_FileInputStream {
	//ctrl+shift+f : 소스 정렬
	//cyrl+shift+o : import 정리
	public static void main(String[] args) {
		String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\src\\com\\pcwk\\ehr\\ed04\\Ed04_FileInputStream.java";
		// C:\JSPM_0907\01_JAVA\WORKSPACE\J25\src\log4j2.properties
		// String filePath = args[0];
		System.out.println("filePath:" + filePath);

//		- try ~ with ~ resource : JDK 1.7에 추가, 리소스 자원 반납을 자동으로 하도록 API제공
//	    (API내부에서 close()를 명시적으로 호출 : AutoCloseable 인터페이스를 구현한 예외만)
		try (FileInputStream fis = new FileInputStream(filePath);) {
			int data = 0; // 1byte
			while ((data = fis.read()) != -1) {
				char ch = (char) data;// int 4byte -> char로 casting
				System.out.print(ch);// byte 0 ~ 255 범위의 정수 데이터 이므로 char 형변환
			}

		} catch (IOException e) {
			System.out.println("IOException:" + e.getMessage());
		}
		System.out.println("=======================");
		System.out.println("=End=");
		System.out.println("=======================");

	}

}
