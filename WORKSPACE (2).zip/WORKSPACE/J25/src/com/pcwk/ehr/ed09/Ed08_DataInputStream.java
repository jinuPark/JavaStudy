package com.pcwk.ehr.ed09;

import java.io.*;

public class Ed08_DataInputStream {

	public static void main(String[] args) {
		// C:\JSPM_0907\01_JAVA\WORKSPACE\J25\pcwk.dat
		String filePath = "C:\\JSPM_0907\\01_JAVA\\WORKSPACE\\J25\\pcwk.dat";
		// try~with resource: close()함수 호출 불필요
		try (FileInputStream fis = new FileInputStream(filePath); 
				DataInputStream dis = new DataInputStream(fis);) {
			//기록된 순서대로 데이터 읽기: 순서가 어긋나면 데이터를 읽을수 없다.
			System.out.println(dis.readBoolean());
			System.out.println(dis.readByte());
			System.out.println(dis.readChar());
			System.out.println(dis.readInt());
			System.out.println(dis.readDouble());
			System.out.println(dis.readUTF());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

}
//true
//123
//A
//16
//3.14
//환절기 감기 조심하세요.