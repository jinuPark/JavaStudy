package com.pcwk.ehr.ed02;

public class Ed02_Thread extends Thread {

	@Override
	public void run() {
		for(int i=1; i<=5; i++) {
			System.out.println(getName());
		}
	}
	
}
