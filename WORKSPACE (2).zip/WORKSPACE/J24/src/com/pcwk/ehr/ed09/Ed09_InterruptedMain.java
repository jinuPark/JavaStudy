package com.pcwk.ehr.ed09;

import javax.swing.JOptionPane;

public class Ed09_InterruptedMain {

	public static void main(String[] args) {
		ThreadInterupped2 th01 = new ThreadInterupped2();
		th01.start();
		
		String input = JOptionPane.showInputDialog("입력하세요.");
		
		System.out.println("입력한 값은 "+input +" 입니다.");
		
		//스레드를 interrupt를 호출 : isInterrupted가 true가 된다.
		th01.interrupt();
		System.out.println("th01.isInterrupted: "+th01.isInterrupted());
	}

}

//10
//9
//8
//7
//6
//5
//입력한 값은 111 입니다.
//th01.isInterrupted: true
//카운트 다운이 종료 되었습니다.

