package com.pcwk.ehr.ed10;

import javax.swing.text.html.HTMLDocument.Iterator;

public class Ed10_Main {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		RunnableStop runAble=new RunnableStop();
		
		Thread  th01=new Thread(runAble, "*");
		Thread  th02=new Thread(runAble, "**");
		Thread  th03=new Thread(runAble, "***");
		
		th01.start();
		th02.start();
		th03.start();
//		suspend()은 스레드를 멈추게 한다. 
//		suspend()에 의해 정지된 스레드는 resume()를 호출해야 다시 실행대기 상태가 된다. 
//		stop()은 호출 즉시 스레드가 종료된다.		
		try {
			 
			Thread.sleep(2000);
			th01.suspend();//th01을 잠시 중단 한다.
			
			Thread.sleep(2000);
			th02.suspend();//th02을 잠시 중단 한다.
			
			Thread.sleep(3000);
			th01.resume();//th01을 다시 동작하도록 한다.
			
			Thread.sleep(3000);
			th01.stop();//th01강제 종료
			th02.stop();//th02강제 종료
			System.out.println("th01 종료!");
			System.out.println("th02 종료!");
			
			Thread.sleep(3000);
			th03.stop();
			System.out.println("th03 종료!");
		}catch(InterruptedException  e) {
			
		}
		System.out.println("프로그램 종료!");

	}

}
//**
//***
//*
//***
//**
//*
//***
//**
//***
//**
//***
//***
//***
//*
//***
//*
//***
//*
//***
//th01 종료!
//th02 종료!
//***
//***
//***
//th03 종료!
//프로그램 종료!