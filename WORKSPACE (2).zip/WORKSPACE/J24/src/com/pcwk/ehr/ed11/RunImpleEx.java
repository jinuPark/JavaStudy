package com.pcwk.ehr.ed11;

public class RunImpleEx implements Runnable {
	boolean suspended = false;
	boolean stopped   = false;

//	-suspend()은 스레드를 멈추게 한다. 
//	suspend()에 의해 정지된 스레드는 resume()를 호출해야 다시 실행대기 상태가 된다. 
//	stop()은 호출 즉시 스레드가 종료된다.	
	@Override
	public void run() {
		
		while(!stopped) {//stopped==false동안 반복
			
			if(!suspended) {//suspended == false 동안 반복
				System.out.println(Thread.currentThread().getName());
			}
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println(Thread.currentThread().getName()+"- stopped!");

	}
	
	public void suspend() {
		suspended = true;
	}
	
	public void stop() {
		stopped = true;
	}

	public void resume() {
		suspended = true;
		
	}

}