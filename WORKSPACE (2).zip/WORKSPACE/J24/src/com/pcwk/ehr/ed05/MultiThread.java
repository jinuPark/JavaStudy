package com.pcwk.ehr.ed05;

public class MultiThread extends Thread {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i = 10; i > 0; i--) {
			System.out.println(i);
			
			try {
				Thread.sleep(1000);//1초(1000 ) 대기
			} catch (InterruptedException e) {
				//e.printStackTrace();
				System.out.println("InterruptedException:"+e.getMessage());
			}
			
		}
	}

}
