package com.pcwk.ehr.ed05;

import javax.swing.JOptionPane;

public class Ed07_MultiThreadMain2 {

	public static void main(String[] args) {
		
		MultiThread mTh = new MultiThread();

//		Thread.MAX_PRIORITY;
//		Thread.MIN_PRIORITY;
//		Thread.NORM_PRIORITY;
//	    /**
//	     * The minimum priority that a thread can have.
//	     */
//	    public final static int MIN_PRIORITY = 1;
//	   /**
//	     * The default priority that is assigned to a thread.
//	     */
//	    public final static int NORM_PRIORITY = 5;
//	    /**
//	     * The maximum priority that a thread can have.
//	     */
//	    public final static int MAX_PRIORITY = 10;

		
		
		mTh.start();
		
		String input = JOptionPane.showInputDialog("점심 메뉴 입력");
		System.out.println("입력 하신 값은 "+input+" 입니다.");

	}

}


//10
//9
//8
//7
//입력 하신 값은 비빔밥 입니다.
//6
//5
//4
//3
//2
//1
