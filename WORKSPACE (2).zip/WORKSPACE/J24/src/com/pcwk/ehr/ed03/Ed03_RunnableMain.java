package com.pcwk.ehr.ed03;

public class Ed03_RunnableMain {

	public static void main(String[] args) {
		
		Runnable runable = new ThreadRunnable();// Runnable인터페이스를 구현한 클래스의 인스턴스 생성
		Thread thread = new Thread(runable);// 생성자에 인자로 Runnable 인터페이스 할당

		//JVM이 run()메서드 호출 함.
		thread.start();

	}

}
