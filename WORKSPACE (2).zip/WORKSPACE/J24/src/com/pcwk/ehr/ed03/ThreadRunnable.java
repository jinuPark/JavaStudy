package com.pcwk.ehr.ed03;

public class ThreadRunnable implements Runnable {

	@Override
	public void run() {
		for(int i = 1; i <= 5; i++) {
			System.out.println("쓰레드 실행중 :"+i);
		}

	}

}
