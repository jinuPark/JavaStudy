package com.pcwk.ehr.ed04;

public class Ed05_MultiMain {

	static long startTime = 0;
	public static void main(String[] args) {

		MultiThread mTh = new MultiThread();
		mTh.start();//thread call
		
		startTime = System.currentTimeMillis();
		for(int i=0; i<300; i++) {
			System.out.printf("%s", new String("-"));
		}		
	
		for(int i=0; i<300; i++) {
			System.out.printf("%s", new String("|"));
		}	

		long endTime = System.currentTimeMillis();
		
		System.out.println("소요시간 1: "+(endTime - startTime));
	}

}
