package com.pcwk.ehr.ed03;

import com.pcwk.ehr.cmn.PLogger;

public class Ex10_Math implements PLogger{

	public static void main(String[] args) {
		double dVal = 90.7552d;
		
		System.out.println("반올림");
		// Math.round(dVal):91
		System.out.println("Math.round(dVal):"+Math.round(dVal));
		
		dVal = dVal * 100;
		// Math.round(dVal):9076
		System.out.println("Math.round(dVal):"+Math.round(dVal));
		
		// Math.round(dVal)/100:90
		//System.out.println("Math.round(dVal)/100:"+Math.round(dVal)/100);
		// Math.round(dVal)/100:90.76
		System.out.println("Math.round(dVal)/100:"+Math.round(dVal)/100.0);
		
		//올림 : Math.ceil()
		System.out.println("================================");
		System.out.println("올림");

		System.out.println("Math.ceil(1.1):"+Math.ceil(1.1));
		System.out.println("Math.ceil(-1.5):"+Math.ceil(-1.5));

		System.out.println("================================");
		System.out.println("버림");
		
		System.out.println("Math.floor(1.1):"+Math.floor(1.1));
		System.out.println("Math.floor(-1.5):"+Math.floor(-1.5));

	}

}
//반올림
//Math.round(dVal):91
//Math.round(dVal):9076
//Math.round(dVal)/100:90.76
//================================
//올림
//Math.ceil(1.1):2.0
//Math.ceil(-1.5):-1.0
//================================
//버림
//Math.floor(1.1):1.0
//Math.floor(-1.5):-2.0
