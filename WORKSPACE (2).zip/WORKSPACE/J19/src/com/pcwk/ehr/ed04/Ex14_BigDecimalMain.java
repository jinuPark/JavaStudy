package com.pcwk.ehr.ed04;

import java.math.BigDecimal;

public class Ex14_BigDecimalMain {

	public static void main(String[] args) {
		BigDecimal num1 = new BigDecimal("123.456");
		BigDecimal num2 = new BigDecimal("1.0");

		// 더하기
		BigDecimal resultAdd = num1.add(num2);
		System.out.println("num1.add(num2)"+resultAdd);
		
		// 빼기
		BigDecimal resultSubtract = num1.add(num2);
		System.out.println("num1.subtract(num2)"+resultSubtract);
		
		// 곱하기
		BigDecimal resultMultiply = num1.multiply(num2);
		System.out.println("num1.multiply(num2)"+resultMultiply);

		// 나누기 (반올림 모드 설정 가능)
		BigDecimal result = num1.divide(num2, 2, BigDecimal.ROUND_HALF_UP);
		System.out.println("num1.divide(num2, 2, BigDecimal.ROUND_HALF_UP:"+result);
		
		//데이터 비교
		if (num1.equals(num2)) {
			System.out.println("두 개의 BigDecimal은 같다.");
		} else {
			System.out.println("두 개의 BigDecimal은 다르다.");
		}
		
	}

}


//num1.add(num2)124.456
//num1.subtract(num2)124.456
//num1.multiply(num2)123.4560
//num1.divide(num2, 2, BigDecimal.ROUND_HALF_UP:123.46
//두 개의 BigDecimal은 다르다.

