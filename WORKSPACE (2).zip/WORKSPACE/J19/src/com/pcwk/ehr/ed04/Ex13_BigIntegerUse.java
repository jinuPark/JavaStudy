package com.pcwk.ehr.ed04;

import java.math.BigInteger;

public class Ex13_BigIntegerUse {

	public static void main(String[] args) throws InterruptedException {
	
		for(int i=1; i<100; i++) { // 1 ~ 99!
			System.out.printf("%d!=%s\n",i, calcFactorial(i));
			//public static void main(String[] args) throws InterruptedException
			Thread.sleep(500);//0.5대기
		}

	}

	//int를 BigInteger로 변환 해서 factorial()함수 호출
	static String calcFactorial(int n) {
		return factorial(BigInteger.valueOf(n)).toString();
	}
	
	
	static BigInteger factorial(BigInteger n) {
		if(n.equals(BigInteger.ZERO)) {
			return BigInteger.ONE;
		} else {
			//return n * factorial(n-1)
			return n.multiply(factorial(n.subtract(BigInteger.ONE)) );
		}
	}

}
//1!=1
//2!=2
//3!=6
//4!=24
//5!=120
//6!=720
//7!=5040
//8!=40320
//9!=362880
//10!=3628800
//11!=39916800
//...