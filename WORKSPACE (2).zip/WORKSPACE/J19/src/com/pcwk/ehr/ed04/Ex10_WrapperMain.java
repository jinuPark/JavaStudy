package com.pcwk.ehr.ed04;

import com.pcwk.ehr.cmn.PLogger;

public class Ex10_WrapperMain implements PLogger{

	public static void main(String[] args) {

		Integer iValue = new Integer(23);
		
		Integer sValue = new Integer("23");

		LOG.debug("iValue="+iValue);
		LOG.debug("sValue="+iValue);
		LOG.debug("------------------");
		//클래스를 기본자료형 int변환 : 자료형+Value()형식으로 사용하면 해당 자료형으로 변환 가능
		int myIntValue = iValue.intValue();
		LOG.debug("myIntValue="+myIntValue);
		
		LOG.debug("Integer는 "+Integer.SIZE+" bit");//Integer는 32bit
		LOG.debug("Integer는 "+Integer.BYTES+" byte");//Integer는 4 byte

		LOG.debug("최대값:"+Integer.MAX_VALUE);//2147483647
		LOG.debug("최소값:"+Integer.MAX_VALUE);//-2147483647
		LOG.debug("------------------");
		
		Long lValue = new Long(22);
		LOG.debug("lvalue:"+lValue);
		long myLongValue = lValue.longValue();
		LOG.debug("MyLongValue:" +myLongValue);

		LOG.debug("Long는"+Long.BYTES+" byte"); //Long는 8 byte

		LOG.debug("Long는"+Long.MAX_VALUE); //9223372036854775807
		LOG.debug("Long는"+Long.SIZE+" bit"); //Long는 64 bit
	}

}
