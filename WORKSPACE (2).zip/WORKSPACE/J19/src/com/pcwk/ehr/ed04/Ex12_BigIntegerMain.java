package com.pcwk.ehr.ed04;

import java.math.BigInteger;

public class Ex12_BigIntegerMain {

	public static void main(String[] args) {
		// Long이 표현 할 수 있는 최대값
		System.out.println("Long.MAX_VALUE:"+Long.MAX_VALUE);
		System.out.println("9223372036854775807".length());//19
		System.out.println(Long.MAX_VALUE+22); //쓰레기 값
		
		BigInteger num01 = new BigInteger("9223372036854775807");
		BigInteger num02 = new BigInteger("1000000000000000000");

		BigInteger resultAdd = num01.add(num02);
		BigInteger resultsubtract = num01.subtract(num02);
		BigInteger resultMultiply = num01.multiply(num02);
		BigInteger resultDivide = num01.divide(num02);
		
		
		System.out.println("num01.add(num02):"+resultAdd);
		System.out.println("num01.subtract(num02):"+resultsubtract);
		System.out.println("num01.multiply(num02):"+resultMultiply);
		System.out.println("num01.divide(num02):"+resultDivide);
		
		System.out.println("BigInteger.ZERO:"+BigInteger.ZERO);
		System.out.println("BigInteger.ONE:"+BigInteger.ONE);
		System.out.println("BigInteger.TEN:"+BigInteger.TEN);
		
	}

}

//Long.MAX_VALUE:9223372036854775807
//19
//-9223372036854775787
//num01.add(num02):10223372036854775807
//num01.subtract(num02):8223372036854775807
//num01.multiply(num02):9223372036854775807000000000000000000
//num01.divide(num02):9
//BigInteger.ZERO:0
//BigInteger.ONE:1
//BigInteger.TEN:10
