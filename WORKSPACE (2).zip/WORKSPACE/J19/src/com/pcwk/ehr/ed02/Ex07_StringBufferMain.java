package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;

public class Ex07_StringBufferMain implements PLogger{

	//static final Logger LOG = LogManager.getLogger(Ex07_StringBufferMain.class);

	public static void main(String[] args) {
		//StringBuilder sb = new StringBuilder();
		// thread safe: 속도는 StringBuilder에 비해 느리다.
		StringBuffer sb = new StringBuffer();//16개 문자 저장
		LOG.debug("sb.capacity()"+sb.capacity());
		LOG.debug("sb.length()"+sb.length());

		
		sb.append("12345678901234567");
		//용량이 가득 차면 자동으로 capacity 증가된다.
		LOG.debug("sb.capacity()"+sb.capacity());
		LOG.debug("sb.length()"+sb.length());
		LOG.debug(sb.toString());
	}

}

//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:11) - sb.capacity()16
//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:12) - sb.length()0
//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:17) - sb.capacity()34
//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:18) - sb.length()17


