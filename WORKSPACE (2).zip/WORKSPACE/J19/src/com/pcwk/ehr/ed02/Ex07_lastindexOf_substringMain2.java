package com.pcwk.ehr.ed02;

public class Ex07_lastindexOf_substringMain2 {

	public static void main(String[] args) {
		
		// 파일 이름에 "."이 들어갈 수 있으므로 : 항상 뒤에서 부터 읽어야 한다.
		String fullName = "He.llo.java";
		
		int idx = fullName.lastIndexOf(".");
		System.out.println(idx);
		
		//Hello
		String fileName = fullName.substring(0, idx);//0<=x<5
		System.out.println("fileName:"+fileName);
		
		//java
		String ext = fullName.substring(idx+1);
		System.out.println("ext:"+ext);

		
	}

}

//6
//fileName:He.llo
//ext:java

