package com.pcwk.ehr.ed02;

public class Ex03_ByteToStringMain {

	public static void main(String[] args) {
		// Helo Java
		byte[] bytes = {72, 101, 108, 111, 32, 74, 97, 118, 97};

		String str01 = new String(bytes);
		System.out.println(str01);

		String str02 = new String(bytes,5,4); // Java
		System.out.println(str02);
		
	}
}
