package com.pcwk.ehr.ed02;

public class Ex02_StringEquals {

	public static void main(String[] args) {
		String str01 = "abc";
		String str02 = "abc";
		System.out.println("str01==str02->"+ (str01==str02));
		System.out.println("str01.equals(str02)->"+ (str01.equals(str02)));
		

		String str03 = new String("abc");
		String str04 = new String("abc");
		System.out.println("str03==str04->"+ (str03==str04));
		System.out.println("str03.equals(str04)->"+ (str03.equals(str04)));
		

		
	}

}
//
//str01==str02->true
//str01.equals(str02)->true
//str03==str04->false
//str03.equals(str04)->true
