package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;

public class Ex09_StringMethodMain implements PLogger{
	
	//지정된 문자열의 포함 여부 검사
	public static void pcwkContains() {
		String str = "abcdefghij";

		//LOG.debug(str.contains("z"));// false
		LOG.debug(str.contains("fg"));// true
	}
	
	
	//문자열의 길이
	public static void pcwkLength() {
		String str = "Hello";
		LOG.debug("str.length():"+str.length());
		
		for(int i = 0; i < str.length(); i++) {
			System.out.println(str.charAt(i));
		}
	}
	
	//문자열을 지정된 문자로 나누어 배열로 반환
	public static void pcwkSplit() {
		String cellPhone = "010-1234-5678";
		String []numStr = cellPhone.split("-");
		
		StringBuilder sb = new StringBuilder();
		for(String str : numStr) {
			sb.append(str);
		}
		
		LOG.debug(sb.toString());
	}
	
	//trim() : 앞뒤 공백 제거
	public static void pcwkTrim() {
		String str = " Hello  World! ";
		LOG.debug("str:"+str);
		LOG.debug("str:"+str.trim());
	}

	public static void main(String[] args) {
		pcwkContains();
		pcwkLength();
		pcwkSplit();
		pcwkTrim();
		
	}

}
