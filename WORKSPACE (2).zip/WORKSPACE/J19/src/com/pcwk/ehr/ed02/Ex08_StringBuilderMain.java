package com.pcwk.ehr.ed02;

import com.pcwk.ehr.cmn.PLogger;

public class Ex08_StringBuilderMain implements PLogger{

	//static final Logger LOG = LogManager.getLogger(Ex07_StringBufferMain.class);

	public static void main(String[] args) {
		// thread unsafe: 속도는 StringBuffer에 비해 속도가 빠르다.
		StringBuilder sb = new StringBuilder();
		//StringBuffer sb = new StringBuffer();//16개 문자 저장
		LOG.debug("sb.capacity()"+sb.capacity());
		LOG.debug("sb.length()"+sb.length());

		
		sb.append("12345678901234567 \n");
		sb.append("SELECT	\n");
		sb.append("NO	\n");
		sb.append(",NAME	\n");
		sb.append("FROM member	\n");
		sb.append("WHERE name ='kim'	\n");
		
		//용량이 가득 차면 자동으로 capacity 증가된다.
		LOG.debug("sb.capacity()"+sb.capacity());
		LOG.debug("sb.length()"+sb.length());
		LOG.debug(sb.toString());
	}

}

//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:11) - sb.capacity()16
//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:12) - sb.length()0
//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:17) - sb.capacity()34
//[2023-10-06 12:03:30] DEBUG Ex07_StringBufferMain.main(Ex07_StringBufferMain.java:18) - sb.length()17


