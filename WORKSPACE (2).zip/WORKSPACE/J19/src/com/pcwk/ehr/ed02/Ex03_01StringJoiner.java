package com.pcwk.ehr.ed02;
import java.util.StringJoiner;

public class Ex03_01StringJoiner {

	public static void main(String[] args) {
		String animals = "dog,cat,bear";
		
		String[] strArr = animals.split(",");
		
		for(String str :strArr) {
			System.out.println(str);
		}
		
		// dog-cat-bear
		System.out.println(String.join("-", strArr));
		
		// [dog/cat/bear]
		StringJoiner sj = new StringJoiner("/", "[", "]");
		

		for(String str :strArr) {
			sj.add(str);		
		}

		System.out.println(sj.toString());

	}
}

//dog
//cat
//bear
//dog-cat-bear
//[dog/cat/bear]

