package com.pcwk.ehr.ed05;
import java.io.*;

public class Ed05_FileDirectory {

	public static void main(String[] args) {
		//C:\JSPM_0907\01_JAVA\WORKSPACE\J26\src\com\pcwk\ehr\ed02
		if(args.length !=1) {
			System.out.println("디렉토리를 입력 하세요.");
			System.exit(0);
		}
		
		System.out.println("디렉토리:"+args[0]);

		File f=new File(args[0]);
		
		if(!f.exists() || !f.isDirectory()) {//존재하지 않거나 || 디렉토리가 아니면
			System.out.println("유효한 디렉토리를 입력 하세요.");
			System.exit(0);
		}
		
		File[] files = f.listFiles();
		
		for(int i=0;i<files.length;i++) {
			String name = files[i].getName();//file/directory명
			
			System.out.println(files[i].isDirectory()?"["+name+"]":name);
		}

	}

}