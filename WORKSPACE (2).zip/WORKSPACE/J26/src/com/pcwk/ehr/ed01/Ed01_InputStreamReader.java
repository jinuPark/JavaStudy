package com.pcwk.ehr.ed01;

import com.pcwk.ehr.cmn.PLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Ed01_InputStreamReader implements PLogger{

	
	public static void main(String[] args) {
		LOG.debug("오늘은 즐거운 수요일!");
		
		String line = "";
		InputStreamReader isr = null;
		BufferedReader	  br = null;
		try {
			isr = new InputStreamReader(System.in);
			br = new BufferedReader(isr);
			LOG.debug("사용 중인 인코딩: "+isr.getEncoding());

			do {
				System.out.print("문자를 입력 하세요>");
				line = br.readLine();
				System.out.println("입력 문장:"+line);
				
			}while(!line.equalsIgnoreCase("q"));
			
		}catch(IOException e) {
			
		}finally {
			if (null != br) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		LOG.debug("프로그램 종료!");
		
	}
}
