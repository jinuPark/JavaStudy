package com.pcwk.ehr.ed02;

import java.util.Scanner;

public class Ed07_Switch {

	public static void main(String[] args) {
		
		
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");
		System.out.println("오늘은 즐거운 목요일!");

		for(int i=1; i<=5; i++) {
			System.out.println("오늘은 즐거운 목요일!");
		}
		
	}//--main

}//--class


//주민번호를 입력하세요.(971231-1234567)>
//971231-1234567
//regno=971231-1234567
//regno=1
//2000년 이전 출생
//성별: 남자

