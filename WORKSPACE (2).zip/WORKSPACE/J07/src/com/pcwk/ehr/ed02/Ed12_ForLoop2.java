package com.pcwk.ehr.ed02;

public class Ed12_ForLoop2 {

	public static void main(String[] args) {

		int sum = 0;
		// 홀수
		for (int i = 1; i <= 10; i++) {
			
			if(i%2 != 0) {
				sum += i; // sum = sum + i
				System.out.println(i);					
			}
		}
		System.out.printf("sum=%d", sum);

		//-----------------------------------------
		System.out.println("");
		
		
		sum = 0;
		for (int i=1; i<=10; i+=2) {
			sum+=i;
			System.out.println(i);
		}
		System.out.printf("sum=%d\n",sum);

	}

}



//1
//3
//5
//7
//9
//sum=25------------
//1
//3
//5
//7
//9
//sum=25