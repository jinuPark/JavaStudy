package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed06_Switch {

	public static void main(String[] args) {
		// 1. 주민번호 13자리 입력
		// 2.
		//  alt+shift+a : 세로 편집 모드
		// 	2000년 이전	2000년 이후
		// 	1	남자		3
		// 	2	남자		4
		char gender = ' '; 	// 성별
		String message = "";// 
		
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("주민번호를 입력하세요.(971231-1234567)>");//0번지 부터 시작 7번째가 성별
		String regNo = scanner.nextLine();
		
		System.out.printf("regno=%s\n", regNo);
		
		gender = regNo.charAt(7);
		System.out.printf("regno=%s\n", gender);
		
		switch(gender) {
		case '1': case '3': 
			message = "남자";
			
			switch(gender) {
			case '1':
				System.out.println("2000년 이전 출생");
				break;
			case '3':
				System.out.println("2000년 이후 출생");
				break;
			}//--안쪽 switch
			
			break;
			
		case '2': case '4': 
			message = "여자";
			
			switch(gender) {
			case '2':
				System.out.println("2000년 이전 출생 여자");
				break;
			case '4':
				System.out.println("2000년 이후 출생 여자");
				break;
			}//--안쪽 switch
			break;	
		}
		
		System.out.printf("성별: %s%n", message);
		
	}//--main

}//--class


//주민번호를 입력하세요.(971231-1234567)>
//971231-1234567
//regno=971231-1234567
//regno=1
//2000년 이전 출생
//성별: 남자

