package com.pcwk.ehr.ed01;

import java.util.Scanner;

public class Ed01_Switch {

	public static void main(String[] args) {
		int score = 0; //점수
		char grade = ' ';
		
		
		Scanner scanner = new Scanner(System.in);

		System.out.print("점수를 입력하세요.>");
		score = scanner.nextInt();
		System.out.printf("score=%d\n", score);
		
		System.out.printf("score/10=%d\n", score/10);
		
		switch(score/10) {
		case 10:	// 의도적으로 break문 생략
		case 9:
			grade = 'A';
			break;
		case 8:
			grade = 'B';
			break;
		case 7:
			grade = 'C';
			break;
		case 6:
			grade = 'D';
			break;
		default:
			grade = 'F';
			break;
		}//-- switch
		
		System.out.printf("학점:%c%n", grade);
		
	}//-- main

}//-- class


//점수를 입력하세요.>100
//score=100
//score/10=10
//학점:A
