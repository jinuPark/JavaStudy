
public class Ed07_Command {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("args.length:"+args.length);

		//args.length:0
		for (String str :args) {
			System.out.println(str);
		}
	}

}

//args.length:3
//점심
//맛나게
//하세요
