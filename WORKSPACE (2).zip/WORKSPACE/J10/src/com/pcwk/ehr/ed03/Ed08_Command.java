package com.pcwk.ehr.ed03;

public class Ed08_Command {

	public static void main(String[] args) {
		// 화면으로 부터 사칙연산을 수식을 입력받아 계산하는 프로그램 작성.
		// num1 OP num2 →연산결과
		System.out.println("args.length:"+args.length);

		
		for(int i=0; i<args.length; i++) {
			System.out.printf("args[%d]=%s\n", i, args[i]);
			
		}
		
		if(args.length !=3) {	// 입력 값의 개수가 3개가 아니면 
			System.out.println("사용 : Ed08_Command (8 + 9).");
			System.exit(0);		// 프로그램 종료
		}
		
		int num01 = Integer.parseInt(args[0]);//"8" -> 8
		char op   = args[1].charAt(0);//연산자
		int num02 = Integer.parseInt(args[2]);//"9" -> 9 
		
		int result = 0;	// 결과
		
		switch(op) {
		case '+' :
			result = num01 + num02;
			break;
		case '-' :
			result = num01 - num02;
			break;
		case 'x' :
			result = num01 * num02;
			break;
		case '/' :
			result = num01 / num02;
			break;
		}
		
		
		System.out.printf("%d %c %d", num01, op, num02, result);
		System.out.println("결과 : "+result);
	}//--main

}//--class



//args.length:3
//args[0]=88
//args[1]=x
//args[2]=2
//88 x 2결과 : 176
