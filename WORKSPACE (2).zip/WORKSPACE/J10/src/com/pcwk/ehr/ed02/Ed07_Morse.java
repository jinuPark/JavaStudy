package com.pcwk.ehr.ed02;

public class Ed07_Morse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String source = "0105401";
		String[] morse = {  
				 ".-"
				 ,"-..."
				 ,"-.-."
				 ,"-.."
				 ,"."
				 ,"..-."
				 ,"--."
				 ,"...."
				 ,".."
				 ,".---"
				 ,"-.-"
				 ,".-.."
				 ,"--"
				 ,"-."
				 ,"---"
				 ,".--."
				 ,"--.-"
				 ,".-."
				 ,"..."
				 ,"-"
				 ,"..-"
				 ,"...-"
				 ,".-- "
				 ,"-..-"
				 ,"-.--"
				 ,"--.."
				,	"-----"// 숫자
				,	".----"
				,	"..---"
				,	"...--"
				,	"....-"
				,	"....."
				,	"-...."
				,	"--..."
				,	"---.."
				,	"----."
		 };

		 String result = ""; // 반환 결과용
		 
		 for (int i = 0; i < source.length(); i++) {

			 if (source.charAt(i) >= 'A' && source.charAt(i) <= 'Z') {
				 result += morse[(source.charAt(i) - 'A')];
			 }
			 
			 else if (source.charAt(i) >= '0' && source.charAt(i) <= '9') {
				 result += morse[(source.charAt(i) -'0'+26)];
			 }
		 }
		 

		 System.out.println("source:" + source);
		 System.out.println("모르스 부호:" + result);

	}//--main

}//--class