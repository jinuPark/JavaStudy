package com.pcwk.ehr.ed02;

public class Ed06_Morse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String source = "ASOSHELP";
		String[] morse = {  
				 ".-"
				 ,"-..."
				 ,"-.-."
				 ,"-.."
				 ,"."
				 ,"..-."
				 ,"--."
				 ,"...."
				 ,".."
				 ,".---"
				 ,"-.-"
				 ,".-.."
				 ,"--"
				 ,"-."
				 ,"---"
				 ,".--."
				 ,"--.-"
				 ,".-."
				 ,"..."
				 ,"-"
				 ,"..-"
				 ,"...-"
				 ,".-- "
				 ,"-..-"
				 ,"-.--"
				 ,"--.."
		 };

		 String result = ""; // 반환 결과용
		 for (int i = 0; i<source.length(); i++) {
			 // 모르스부호 : A=0;
			 // source.charAt(i) - 'A' : 알파벳 char - 'A' -> 모르스 부호 인덱스와 메핑
			 //System.out.println(source.charAt(i));
			 //System.out.println(source.charAt(i) - 'A');
			 //System.out.printf("%c \t index=%d\n", source.charAt(i), (source.charAt(i) - 'A'));

			 // 케릭터 A - A 는 0임.
			 result = morse[(source.charAt(i) - 'A')];
			 System.out.println(result);
		 }
		 

		 System.out.println("source:"+source);
		 System.out.println("모르스 부호:"+result);

	}//--main

}//--class


//hex:CAFE2
//reslut:1100,1010,1111,1110,0010,

